package com.itheima.mobilesafeteach.view;

import android.content.Context;
import android.graphics.PixelFormat;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.widget.TextView;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.utils.PrefUtils;

/**
 * 自定义Toast
 * 
 * @author Kevin
 * @date 2015-12-13
 */
public class AddressToast implements OnTouchListener {

	private WindowManager mWM;
	private WindowManager.LayoutParams mParams;

	private View mView;
	private TextView tvToast;

	private int startX;
	private int startY;

	private Context mContext;

	public AddressToast(Context ctx) {
		mContext = ctx;

		// 获取窗口管理器
		mWM = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);

		// 加载窗口布局
		mView = View.inflate(ctx, R.layout.toast_address, null);
		tvToast = (TextView) mView.findViewById(R.id.tv_toast);

		mView.setOnTouchListener(this);

		// 初始化窗口布局参数
		mParams = new WindowManager.LayoutParams();
		mParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
		mParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
		mParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
				| WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
		mParams.format = PixelFormat.TRANSLUCENT;
		mParams.type = WindowManager.LayoutParams.TYPE_PRIORITY_PHONE;
	}

	/**
	 * 展示Toast
	 */
	public void show(String address) {
		// 修改布局背景样式
		int style = PrefUtils.getInt(mContext, "address_style",
				R.drawable.toast_address_normal);
		mView.setBackgroundResource(style);

		tvToast.setText(address);
		mWM.addView(mView, mParams);
	}

	/**
	 * 隐藏Toast
	 */
	public void hide() {
		// 此处要判断 mView.getParent()是否为空, 如果为空,说明mView还没有添加在窗口上, 此时移除mView会出异常
		if (mWM != null && mView != null && mView.getParent() != null) {
			mWM.removeView(mView);
		}
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			// 获取起始坐标
			startX = (int) event.getRawX();
			startY = (int) event.getRawY();
			break;
		case MotionEvent.ACTION_MOVE:
			// 获取坐标偏移量
			int dx = (int) (event.getRawX() - startX);
			int dy = (int) (event.getRawY() - startY);

			// 更新布局参数的x,y坐标
			mParams.x += dx;
			mParams.y += dy;

			System.out.println("当前位置:" + mParams.x + ";" + mParams.y);

			// 更新图片的显示位置
			mWM.updateViewLayout(mView, mParams);

			// 重新初始化起始坐标
			startX = (int) event.getRawX();
			startY = (int) event.getRawY();
			break;

		default:
			break;
		}

		return true;
	}
}
