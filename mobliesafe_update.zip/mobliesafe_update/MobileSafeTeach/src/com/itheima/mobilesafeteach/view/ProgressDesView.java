package com.itheima.mobilesafeteach.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.itheima.mobilesafeteach.R;

/**
 * 自定义进度条组合控件
 * 
 * @author Kevin
 * @date 2015-12-20
 */
public class ProgressDesView extends LinearLayout {

	private TextView tvTitle;
	private TextView tvLeft;
	private TextView tvRight;
	private ProgressBar pbProgress;

	public ProgressDesView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initView();
	}

	public ProgressDesView(Context context, AttributeSet attrs) {
		this(context, attrs, -1);
	}

	public ProgressDesView(Context context) {
		this(context, null);
	}

	private void initView() {
		View.inflate(getContext(), R.layout.view_progress_des, this);
		tvTitle = (TextView) findViewById(R.id.tv_title);
		tvLeft = (TextView) findViewById(R.id.tv_left);
		tvRight = (TextView) findViewById(R.id.tv_right);
		pbProgress = (ProgressBar) findViewById(R.id.pb_progress);
	}

	// 设置标题
	public void setTitle(String title) {
		tvTitle.setText(title);
	}

	// 设置左侧文字
	public void setLeftText(String left) {
		tvLeft.setText(left);
	}

	// 设置右侧文字
	public void setRightText(String right) {
		tvRight.setText(right);
	}

	// 设置进度
	public void setProgress(int progress) {
		pbProgress.setProgress(progress);
	}

}
