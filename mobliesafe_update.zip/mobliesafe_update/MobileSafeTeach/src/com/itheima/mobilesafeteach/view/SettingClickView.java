package com.itheima.mobilesafeteach.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.itheima.mobilesafeteach.R;

/**
 * 自定义设置选项
 * 
 * @author Kevin
 * 
 */
public class SettingClickView extends RelativeLayout {

	private TextView tvContent;
	private TextView tvTitle;

	public SettingClickView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initView();
	}

	public SettingClickView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initView();
	}

	public SettingClickView(Context context) {
		super(context);
		initView();
	}

	/**
	 * 使用布局文件初始化自定义View
	 */
	private void initView() {
		View.inflate(getContext(), R.layout.view_setting_click, this);
		tvContent = (TextView) findViewById(R.id.tv_content);
		tvTitle = (TextView) findViewById(R.id.tv_title);
	}

	/**
	 * 设置文本
	 * 
	 * @param desc
	 */
	public void setDesc(String desc) {
		tvContent.setText(desc);
	}

	/**
	 * 设置标题
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		tvTitle.setText(title);
	}
}
