package com.itheima.mobilesafeteach.view;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListView;

import com.itheima.mobilesafeteach.R;

/**
 * 修改归属地样式-自定义Dialog
 * 
 * @author Kevin
 * @date 2015-12-13
 */
public class AddressDialog extends Dialog {

	private ListView lvList;
	private BaseAdapter mAdapter;
	private OnItemClickListener mListener;

	public AddressDialog(Context context) {
		//设置弹窗样式
		super(context, R.style.AddressDialogStyle);
	}

	// 此方法在dialog创建的时候调用(show方法执行结束之后)
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// 设置dialog布局样式
		setContentView(R.layout.dialog_address);
		
		lvList = (ListView) findViewById(R.id.lv_dialog_address);
		lvList.setAdapter(mAdapter);
		lvList.setOnItemClickListener(mListener);

		// 修改弹窗位置
		Window window = getWindow();// 获取窗口对象
		LayoutParams params = window.getAttributes();// 获取布局参数
		params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;// 显示在屏幕底端居中位置
		window.setAttributes(params);// 重新设置布局参数
	}

	// 给listview填充数据
	public void setAdapter(BaseAdapter adapter) {
		mAdapter = adapter;
	}

	// 设置item点击事件
	public void setOnItemClickListener(OnItemClickListener listener) {
		mListener = listener;
	}

}
