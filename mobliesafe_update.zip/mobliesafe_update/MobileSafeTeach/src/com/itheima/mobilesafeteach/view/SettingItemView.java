package com.itheima.mobilesafeteach.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.itheima.mobilesafeteach.R;

/**
 * 自定义设置选项
 * 
 * @author Kevin
 * 
 */
public class SettingItemView extends RelativeLayout {

	// 三种背景的标识
	private final static int BKG_FIRST = 0;
	private final static int BKG_MIDDLE = 1;
	private final static int BKG_LAST = 2;

	// 自定义属性的命名空间
	private static final String NAMESPACE = "http://schemas.android.com/apk/res/com.itheima.mobilesafeteach";

	private ImageView ivToggle;
	private TextView tvTitle;

	private boolean isToggleOn;// 记录当前开关状态

	public SettingItemView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initView();
	}

	public SettingItemView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initView();

		// int count = attrs.getAttributeCount();
		// for (int i = 0; i < count; i++) {
		// Log.d("Test", "name=" + attrs.getAttributeName(i) + "; value="
		// + attrs.getAttributeValue(i));
		// }

		// 设置标题
		String title = attrs.getAttributeValue(NAMESPACE, "title");
		setTitle(title);

		// 设置背景
		int bg = attrs.getAttributeIntValue(NAMESPACE, "background", 0);
		switch (bg) {
		case BKG_FIRST:
			setBackgroundResource(R.drawable.seting_first_selector);
			break;
		case BKG_MIDDLE:
			setBackgroundResource(R.drawable.seting_middle_selector);
			break;
		case BKG_LAST:
			setBackgroundResource(R.drawable.seting_last_selector);
			break;
		default:
			break;
		}

		// 开关是否显示
		boolean isToggleEnable = attrs.getAttributeBooleanValue(NAMESPACE,
				"toggleEnable", true);
		ivToggle.setVisibility(isToggleEnable ? View.VISIBLE : View.GONE);
	}

	public SettingItemView(Context context) {
		super(context);
		initView();
	}

	/**
	 * 使用布局文件初始化自定义View
	 */
	private void initView() {
		//初始化组合控件布局
		//参3:表示加载的布局对象的父控件是谁, 如果写this,表示加载的布局对象的父控件就是当前的相对布局,也就是说,将布局对象作为孩子添加给了相对布局
		View.inflate(getContext(), R.layout.view_setting_item, this);
		ivToggle = (ImageView) findViewById(R.id.iv_toggle);
		tvTitle = (TextView) findViewById(R.id.tv_title);
	}

	/**
	 * 判断是否已选中
	 * 
	 * @return
	 */
	public boolean isToggleOn() {
		return isToggleOn;
	}

	/**
	 * 设置开关状态
	 */
	public void setToggleOn(boolean isOn) {
		this.isToggleOn = isOn;
		if (isToggleOn) {
			ivToggle.setImageResource(R.drawable.on);
		} else {
			ivToggle.setImageResource(R.drawable.off);
		}
	}

	/**
	 * 切换开关状态(如果当前状态为打开,则切换为关闭状态,反之亦然)
	 */
	public void toggle() {
		setToggleOn(!isToggleOn);
	}

	/**
	 * 设置标题
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		tvTitle.setText(title);
	}
}
