package com.itheima.mobilesafeteach.view;

import android.content.Context;
import android.text.TextUtils.TruncateAt;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * 自定义TextView
 * 
 * @author Kevin
 * 
 */
public class FocusedTextView extends TextView {

	// 带有样式时调用
	public FocusedTextView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);

		setEllipsize(TruncateAt.MARQUEE);//启动跑马灯效果
		setSingleLine();//只显示一行
		setFocusable(true);//设置可获取焦点属性, 只有获取焦点,才能够展示跑马灯效果
		setFocusableInTouchMode(true);//设置可获取焦点属性, 只有获取焦点,才能够展示跑马灯效果
	}

	// 从布局文件中初始化时调用
	public FocusedTextView(Context context, AttributeSet attrs) {
		this(context, attrs, -1);
	}

	// 在代码中new对象时调用
	public FocusedTextView(Context context) {
		this(context, null);
	}

	//当添加两个跑马灯TextView的时候, 只有第一个TextView有跑马灯效果,第二个没有, 因为系统默认只允许一个TextView有焦点
	//通过重写此方法, 让系统认为,当前控件一直处于获取焦点的状态
	@Override
	public boolean isFocused() {
		return true;
	}

}
