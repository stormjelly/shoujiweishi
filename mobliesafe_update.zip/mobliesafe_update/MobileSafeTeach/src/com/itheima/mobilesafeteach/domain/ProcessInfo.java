package com.itheima.mobilesafeteach.domain;

import android.graphics.drawable.Drawable;

public class ProcessInfo {
	public String name;// 名称
	public String packageName;// 包名
	public Drawable icon;// 图标
	public long memory;// 占用内存
	
	public boolean isUserProcess;// 标记是否是用户进程
	
	public boolean isChecked;//标记是否被选中
}