package com.itheima.mobilesafeteach.domain;

/**
 * 首页GridView的item对象封装
 * @author Kevin
 * @date 2016-3-20
 */
public class HomeItemInfo {

	public int iconId;
	public String name;
	public String desc;

}
