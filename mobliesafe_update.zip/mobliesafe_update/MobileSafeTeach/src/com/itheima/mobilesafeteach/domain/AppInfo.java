package com.itheima.mobilesafeteach.domain;

import android.graphics.drawable.Drawable;

/**
 * 应用信息封装
 * 
 * @author Kevin
 * 
 */
public class AppInfo {

	public String name;// 名称
	public String packageName;// 包名
	public Drawable icon;// 图标
	public long size;// 应用大小

	public boolean isUserApp;// 是否是用户程序
	public boolean isRom;// 是否安装在内置存储器中

	@Override
	public String toString() {
		return "AppInfo [name=" + name + ", packageName=" + packageName + "]";
	}

}
