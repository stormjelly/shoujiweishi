package com.itheima.mobilesafeteach.engine;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;

import com.itheima.mobilesafeteach.domain.AppInfo;

/**
 * 应用程序信息提供者
 * 
 * @author Kevin
 * 
 */
public class AppInfoProvider {

	/**
	 * 获取已安装的应用信息
	 * 
	 * @param ctx
	 */
	public static ArrayList<AppInfo> getAppInfos(Context ctx) {

		ArrayList<AppInfo> infoList = new ArrayList<AppInfo>();

		PackageManager pm = ctx.getPackageManager();
		List<PackageInfo> packages = pm.getInstalledPackages(0);// 获取已经安装的所有包

		for (PackageInfo packageInfo : packages) {
			AppInfo info = new AppInfo();

			String packageName = packageInfo.packageName;// 获取包名
			Drawable icon = packageInfo.applicationInfo.loadIcon(pm);// 获取图标

			String name = packageInfo.applicationInfo.loadLabel(pm).toString();// 获取名称

			String sourceDir = packageInfo.applicationInfo.sourceDir;// 获取apk文件安装目录
			long size = new File(sourceDir).length();// 获取安装文件大小

			int flags = packageInfo.applicationInfo.flags;
			// 状态机
			if ((flags & ApplicationInfo.FLAG_SYSTEM) == ApplicationInfo.FLAG_SYSTEM) {// 系统应用
				info.isUserApp = false;
			} else {
				info.isUserApp = true;
			}

			if ((flags & ApplicationInfo.FLAG_EXTERNAL_STORAGE) == ApplicationInfo.FLAG_EXTERNAL_STORAGE) {// sdcard
				info.isRom = false;
			} else {
				info.isRom = true;
			}

			info.packageName = packageName;
			info.icon = icon;
			info.name = name;
			info.size = size;

			infoList.add(info);
		}

		return infoList;
	}
}
