package com.itheima.mobilesafeteach.engine;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.domain.ProcessInfo;

/**
 * 进程信息提供者
 * 
 * @author Kevin
 * 
 */
public class ProcessInfoProvider {

	/**
	 * 获取所有正在运行的进程信息
	 */
	public static ArrayList<ProcessInfo> getProcessInfos(Context ctx) {
		ActivityManager am = (ActivityManager) ctx
				.getSystemService(Context.ACTIVITY_SERVICE);

		PackageManager pm = ctx.getPackageManager();

		// 获取所有正在运行的进程
		List<RunningAppProcessInfo> appProcesses = am.getRunningAppProcesses();

		ArrayList<ProcessInfo> processInfos = new ArrayList<ProcessInfo>();
		for (RunningAppProcessInfo runningAppProcessInfo : appProcesses) {
			ProcessInfo info = new ProcessInfo();

			int pid = runningAppProcessInfo.pid;

			// 获取内存信息
			android.os.Debug.MemoryInfo[] processMemoryInfo = am
					.getProcessMemoryInfo(new int[] { pid });
			android.os.Debug.MemoryInfo memoryInfo = processMemoryInfo[0];
			long totalPrivateDirty = memoryInfo.getTotalPrivateDirty() * 1024;// 获取占用内存大小,
																				// kb
			String packageName = runningAppProcessInfo.processName;// 获取包名

			info.memory = totalPrivateDirty;
			info.packageName = packageName;

			try {
				PackageInfo packageInfo = pm.getPackageInfo(packageName, 0);
				info.icon = packageInfo.applicationInfo.loadIcon(pm);// 获取图标
				info.name = packageInfo.applicationInfo.loadLabel(pm)
						.toString();// 获取名称

				int flags = packageInfo.applicationInfo.flags;

				if ((flags & ApplicationInfo.FLAG_SYSTEM) == ApplicationInfo.FLAG_SYSTEM) {// 系统应用
					info.isUserProcess = false;
				} else {
					info.isUserProcess = true;
				}

			} catch (Exception e) {
				e.printStackTrace();
				// 有些系统级别的进程没有名称和图标, 获取时会抛异常, 在此捕获后设定默认图片,并将包名作为进程名称
				info.icon = ctx.getResources().getDrawable(
						R.drawable.process_default);
				info.name = info.packageName;
				info.isUserProcess = false;
			}

			processInfos.add(info);
		}

		return processInfos;
	}

	/**
	 * 获取正在运行的进程数
	 */
	public static int getRunningProcessNum(Context ctx) {
		ActivityManager am = (ActivityManager) ctx
				.getSystemService(Context.ACTIVITY_SERVICE);
		return am.getRunningAppProcesses().size();
	}

	/**
	 * 获取所有进程的数量
	 * 
	 * @param ctx
	 * @return
	 */
	public static int getTotalProcessNum(Context ctx) {
		PackageManager pm = ctx.getPackageManager();

		// 获取已安装的应用, 参数表示需要额外获取的信息,
		// 包括应用中所有的activity, service, receiver,provider
		List<PackageInfo> installedPackages = pm
				.getInstalledPackages(PackageManager.GET_ACTIVITIES
						| PackageManager.GET_SERVICES
						| PackageManager.GET_RECEIVERS
						| PackageManager.GET_PROVIDERS);

		int count = 0;
		for (PackageInfo packageInfo : installedPackages) {
			// 使用此集合可以避免对象重复添加
			HashSet<String> set = new HashSet<String>();

			// 添加当前应用所占用的进程
			set.add(packageInfo.applicationInfo.processName);

			// 注意: 一个app并不是永远都只占用一个进程, 某些情况下, 可以让四大组件独占一个进程,
			// 所以我们也要把四大组件占用的进程考虑进来

			// 遍历当前应用的activity, 获取activity占用的进程
			// 大部分activity都占用的是一个进程(主应用进程), 但我们使用了HashSet, 会自动做去重处理
			ActivityInfo[] activities = packageInfo.activities;
			if (activities != null) {
				for (ActivityInfo activityInfo : activities) {
					set.add(activityInfo.processName);
				}
			}

			// 遍历当前应用的service, 获取service占用的进程
			ServiceInfo[] services = packageInfo.services;
			if (services != null) {
				for (ServiceInfo serviceInfo : services) {
					set.add(serviceInfo.processName);
				}
			}

			// 遍历当前应用的receiver, 获取receiver占用的进程
			ActivityInfo[] receivers = packageInfo.receivers;
			if (receivers != null) {
				for (ActivityInfo activityInfo : receivers) {
					set.add(activityInfo.processName);
				}
			}

			// 遍历当前应用的providers, 获取providers占用的进程
			ProviderInfo[] providers = packageInfo.providers;
			if (providers != null) {
				for (ProviderInfo providerInfo : providers) {
					set.add(providerInfo.processName);
				}
			}

			count += set.size();
		}

		return count;
	}

	/**
	 * 获取剩余内存
	 */
	public static long getAvailMemory(Context ctx) {
		ActivityManager am = (ActivityManager) ctx
				.getSystemService(Context.ACTIVITY_SERVICE);
		MemoryInfo outInfo = new MemoryInfo();
		am.getMemoryInfo(outInfo);

		return outInfo.availMem;
	}

	/**
	 * 获取总内存
	 */
	public static long getTotalMemory(Context ctx) {
		// API16以下会崩溃
		// ActivityManager am = (ActivityManager) ctx
		// .getSystemService(Context.ACTIVITY_SERVICE);
		// MemoryInfo outInfo = new MemoryInfo();
		// am.getMemoryInfo(outInfo);
		// return outInfo.totalMem;

		BufferedReader br = null;
		FileReader reader = null;
		// 处理兼容问题
		try {
			reader = new FileReader("/proc/meminfo");// 读取系统文件
			br = new BufferedReader(reader);

			char[] readLine = br.readLine().toCharArray();// 获取第一行内容
			StringBuffer sb = new StringBuffer();
			for (char c : readLine) {
				if (c >= '0' && c <= '9') {// 判断是否是数字, 一定要用字符形式的数字,比如'0', 而不是0
					sb.append(c);
				}
			}

			return Integer.parseInt(sb.toString()) * 1024;// 转成整数后,乘以1024转成字节数返回
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
				reader.close();
			} catch (Exception e) {
			}
		}

		return 0;
	}

	/**
	 * 杀死后台所有正在运行的服务
	 * 
	 * @param ctx
	 */
	public static void killAll(Context ctx) {
		ActivityManager am = (ActivityManager) ctx
				.getSystemService(Context.ACTIVITY_SERVICE);
		List<RunningAppProcessInfo> runningAppProcesses = am
				.getRunningAppProcesses();

		for (RunningAppProcessInfo runningAppProcessInfo : runningAppProcesses) {
			// 跳过手机卫士的服务
			if (runningAppProcessInfo.processName.equals(ctx.getPackageName())) {
				continue;
			}

			am.killBackgroundProcesses(runningAppProcessInfo.processName);
		}
	}
}
