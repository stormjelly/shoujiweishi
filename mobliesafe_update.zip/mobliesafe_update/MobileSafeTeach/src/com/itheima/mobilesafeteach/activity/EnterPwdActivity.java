package com.itheima.mobilesafeteach.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.global.GlobalConstants;

/**
 * 加锁输入密码页面
 * 
 * @author Kevin
 * 
 */
public class EnterPwdActivity extends Activity {

	private TextView tvName;
	private ImageView ivIcon;
	private EditText etPwd;
	private Button btnOK;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_enter_pwd);

		tvName = (TextView) findViewById(R.id.tv_name);
		ivIcon = (ImageView) findViewById(R.id.iv_icon);
		etPwd = (EditText) findViewById(R.id.et_pwd);
		btnOK = (Button) findViewById(R.id.btn_ok);

		Intent intent = getIntent();
		final String packageName = intent.getStringExtra("packageName");

		PackageManager pm = getPackageManager();
		try {
			ApplicationInfo info = pm.getApplicationInfo(packageName, 0);// 根据包名获取应用信息
			Drawable icon = info.loadIcon(pm);// 加载应用图标
			ivIcon.setImageDrawable(icon);
			String name = info.loadLabel(pm).toString();// 加载应用名称
			tvName.setText(name);
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}

		btnOK.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String pwd = etPwd.getText().toString().trim();
				if (!TextUtils.isEmpty(pwd)) {// 密码校验
					if (pwd.equals("123")) {
						// 发送广播,通知看门狗不要再拦截当前应用
						Intent intent = new Intent();
						intent.setAction(GlobalConstants.ACTION_SKIP_LOCK);
						intent.putExtra("packageName", packageName);
						sendBroadcast(intent);

						finish();
					} else {
						Toast.makeText(EnterPwdActivity.this, "密码错误",
								Toast.LENGTH_LONG).show();
					}
				} else {
					Toast.makeText(EnterPwdActivity.this, "请输入密码",
							Toast.LENGTH_LONG).show();
				}
			}
		});
	}

	@Override
	public void onBackPressed() {
		// 跳转主页面
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_MAIN);
		intent.addCategory(Intent.CATEGORY_HOME);
		startActivity(intent);

		finish();// 销毁当前页面
	}
}
