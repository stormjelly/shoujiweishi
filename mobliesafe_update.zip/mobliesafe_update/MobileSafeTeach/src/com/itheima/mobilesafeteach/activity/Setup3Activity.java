package com.itheima.mobilesafeteach.activity;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.global.GlobalConstants;
import com.itheima.mobilesafeteach.utils.PrefUtils;

public class Setup3Activity extends BaseSetupActivity {

	private EditText etPhoneNumber;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setup3);
		etPhoneNumber = (EditText) findViewById(R.id.et_phone_number);

		//如果安全号码不为空,更新EditText
		String phone = PrefUtils.getString(this,
				GlobalConstants.PREF_SAFE_PHONE, null);
		if (!TextUtils.isEmpty(phone)) {
			etPhoneNumber.setText(phone);
		}
	}

	/**
	 * 选择联系人
	 * 
	 * @param view
	 */
	public void selectContact(View view) {
		//跳到系统联系人页面选择联系人
		startActivityForResult(new Intent(Intent.ACTION_PICK,
				ContactsContract.Contacts.CONTENT_URI), 0);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == Activity.RESULT_OK) {
			ContentResolver resolver = getContentResolver();
			//获取联系人uri
			Uri contactData = data.getData();
			Cursor cursor = resolver.query(contactData, null, null, null, null);
			cursor.moveToFirst();
			//查询联系人id
			String contactId = cursor.getString(cursor
					.getColumnIndex(ContactsContract.Contacts._ID));
			//根据联系人id查询电话号码
			Cursor phone = resolver.query(
					ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
					ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = "
							+ contactId, null, null);

			String number = "";
			if (phone.moveToNext()) {
				//获取电话号码
				number = phone
						.getString(phone
								.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
			}
			
			cursor.close();
			phone.close();

			number = number.replace("-", "").replace(" ", "");//去掉"-"和空格

			etPhoneNumber.setText(number);
		}

		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public void showNext() {
		String phone = etPhoneNumber.getText().toString().trim();// 过滤掉两侧空格后,获取号码信息

		if (TextUtils.isEmpty(phone)) {
			Toast.makeText(this, "必须设定安全号码!", Toast.LENGTH_SHORT).show();
			return;
		}

		PrefUtils.putString(this, GlobalConstants.PREF_SAFE_PHONE, phone);// 保存电话号码

		Intent intent = new Intent(this, Setup4Activity.class);
		startActivity(intent);
		finish();

		overridePendingTransition(R.anim.trans_in, R.anim.trans_out);// Activity切换的动画效果
	}

	@Override
	public void showPrevious() {
		Intent intent = new Intent(this, Setup2Activity.class);
		startActivity(intent);
		finish();

		overridePendingTransition(R.anim.trans_pre_in, R.anim.trans_pre_out);// Activity切换的动画效果
	}
}
