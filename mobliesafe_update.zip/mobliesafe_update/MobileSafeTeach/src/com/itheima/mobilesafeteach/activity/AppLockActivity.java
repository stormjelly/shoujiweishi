package com.itheima.mobilesafeteach.activity;

import java.util.ArrayList;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.db.dao.AppLockDao;
import com.itheima.mobilesafeteach.domain.AppInfo;
import com.itheima.mobilesafeteach.engine.AppInfoProvider;

/**
 * 程序锁页面
 * 
 * @author Kevin
 * 
 */
public class AppLockActivity extends Activity implements OnClickListener {

	private AppLockDao mDao;

	private TextView tvLocked;// 已加锁标签
	private TextView tvUnlock;// 未加锁标签

	private ListView lvLocked;
	private ListView lvUnLock;

	private TextView tvLockNum;// 加锁/未加锁数量

	private LinearLayout llLoading;// 加载中

	private ArrayList<AppInfo> mList;
	private ArrayList<AppInfo> mLockedList;// 已加锁列表集合
	private ArrayList<AppInfo> mUnlockList;// 未加锁列表集合

	private AppLockAdapter mUnlockAdapter;
	private AppLockAdapter mLockedAdapter;

	//	private Handler mHandler = new Handler() {
	//
	//		public void handleMessage(android.os.Message msg) {
	//			// 设置未加锁数据
	//			mUnlockAdapter = new AppLockAdapter(false);
	//			lvUnLock.setAdapter(mUnlockAdapter);
	//
	//			// 设置已加锁数据
	//			mLockedAdapter = new AppLockAdapter(true);
	//			lvLocked.setAdapter(mLockedAdapter);
	//
	//			llLoading.setVisibility(View.GONE);
	//		};
	//	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_app_lock);

		mDao = AppLockDao.getInstance(this);

		tvLocked = (TextView) findViewById(R.id.tv_locked);
		tvUnlock = (TextView) findViewById(R.id.tv_unlock);
		tvLocked.setOnClickListener(this);
		tvUnlock.setOnClickListener(this);

		lvLocked = (ListView) findViewById(R.id.lv_locked);
		lvUnLock = (ListView) findViewById(R.id.lv_unlock);

		tvLockNum = (TextView) findViewById(R.id.tv_lock_num);
		llLoading = (LinearLayout) findViewById(R.id.ll_loading);

		initData();
	}

	/**
	 * 更新已加锁和未加锁数量
	 */
	private void updateAppNum(boolean isLock) {
		if (isLock) {
			tvLockNum.setText("已加锁(" + mLockedList.size() + ")");
		} else {
			tvLockNum.setText("未加锁(" + mUnlockList.size() + ")");
		}
	}

	/**
	 * 初始化应用列表数据
	 */
	private void initData() {
		//		llLoading.setVisibility(View.VISIBLE);
		//		new Thread() {
		//			@Override
		//			public void run() {
		//				mList = AppInfoProvider.getAppInfos(AppLockActivity.this);
		//
		//				mLockedList = new ArrayList<AppInfo>();
		//				mUnlockList = new ArrayList<AppInfo>();
		//
		//				for (AppInfo info : mList) {
		//					boolean isLocked = mDao.find(info.packageName);
		//					if (isLocked) {
		//						mLockedList.add(info);
		//					} else {
		//						mUnlockList.add(info);
		//					}
		//				}
		//
		//				mHandler.sendEmptyMessage(0);
		//			}
		//		}.start();

		new AppLockAsyncTask().execute();
	}

	/**
	 * 第一个泛型, 参数类型, 和doInBackground参数类型一致 
	 * 第二个泛型, 进度更新的参数类型,和onProgressUpdate参数类型一致 
	 * 第三个泛型, 加载结束的返回结果类型,和onPostExecute参数类型,doInBackground的返回类型一致
	 */
	class AppLockAsyncTask extends AsyncTask<Void, Void, Void> {

		// 预加载, 运行在主线程, 此方法中可以直接更新主界面ui
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			llLoading.setVisibility(View.VISIBLE);
		}

		// 后台异步请求, 运行在子线程, 此方法中可以直接进行耗时操作
		@Override
		protected Void doInBackground(Void... params) {
			mList = AppInfoProvider.getAppInfos(AppLockActivity.this);

			mLockedList = new ArrayList<AppInfo>();
			mUnlockList = new ArrayList<AppInfo>();

			for (AppInfo info : mList) {
				boolean isLocked = mDao.find(info.packageName);
				if (isLocked) {
					mLockedList.add(info);
				} else {
					mUnlockList.add(info);
				}
			}

			return null;
		}

		// 加载结束, 运行在主线程, 此方法中可以直接更新主界面ui
		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			// 设置未加锁数据
			mUnlockAdapter = new AppLockAdapter(false);
			lvUnLock.setAdapter(mUnlockAdapter);

			// 设置已加锁数据
			mLockedAdapter = new AppLockAdapter(true);
			lvLocked.setAdapter(mLockedAdapter);

			llLoading.setVisibility(View.GONE);
		}

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.tv_unlock:// 展示未加锁页面,隐藏已加锁页面
			lvLocked.setVisibility(View.GONE);
			lvUnLock.setVisibility(View.VISIBLE);
			// 修改标签背景
			tvUnlock.setBackgroundResource(R.drawable.tab_left_pressed);
			tvLocked.setBackgroundResource(R.drawable.tab_right_default);
			break;
		case R.id.tv_locked:// 展示已加锁页面,隐藏未加锁页面
			lvUnLock.setVisibility(View.GONE);
			lvLocked.setVisibility(View.VISIBLE);
			// 修改标签背景
			tvUnlock.setBackgroundResource(R.drawable.tab_left_default);
			tvLocked.setBackgroundResource(R.drawable.tab_right_pressed);
			break;
		default:
			break;
		}
	}

	class AppLockAdapter extends BaseAdapter {

		private boolean isLocked;
		private TranslateAnimation mLockAnim;// 加锁的移动动画
		private TranslateAnimation mUnLockAnim;// 去除锁的移动动画

		public AppLockAdapter(boolean isLocked) {
			this.isLocked = isLocked;

			// 右移
			mLockAnim = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0f,
					Animation.RELATIVE_TO_SELF, 1f, Animation.RELATIVE_TO_SELF,
					0, Animation.RELATIVE_TO_SELF, 0);
			mLockAnim.setDuration(500);

			// 左移
			mUnLockAnim = new TranslateAnimation(Animation.RELATIVE_TO_SELF,
					0f, Animation.RELATIVE_TO_SELF, -1f,
					Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF,
					0);
			mUnLockAnim.setDuration(500);
		}

		@Override
		public int getCount() {
			updateAppNum(isLocked);

			if (isLocked) {
				return mLockedList.size();
			} else {
				return mUnlockList.size();
			}
		}

		@Override
		public AppInfo getItem(int position) {
			if (isLocked) {
				return mLockedList.get(position);
			} else {
				return mUnlockList.get(position);
			}
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(final int position, View convertView,
				ViewGroup parent) {
			ViewHolder holder;
			final View view;
			if (convertView == null) {
				convertView = View.inflate(AppLockActivity.this,
						R.layout.list_applock_item, null);
				holder = new ViewHolder();
				holder.ivIcon = (ImageView) convertView
						.findViewById(R.id.iv_icon);
				holder.tvName = (TextView) convertView
						.findViewById(R.id.tv_name);
				holder.ivLock = (ImageView) convertView
						.findViewById(R.id.iv_lock);

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			view = convertView;

			final AppInfo info = getItem(position);
			holder.ivIcon.setImageDrawable(info.icon);
			holder.tvName.setText(info.name);

			if (isLocked) {
				holder.ivLock.setImageResource(R.drawable.btn_unlock_selector);
			} else {
				holder.ivLock.setImageResource(R.drawable.btn_lock_selector);
			}

			holder.ivLock.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					if (isLocked) {
						view.startAnimation(mUnLockAnim);
						mUnLockAnim
								.setAnimationListener(new AnimationListener() {

									@Override
									public void onAnimationStart(
											Animation animation) {
									}

									@Override
									public void onAnimationRepeat(
											Animation animation) {
									}

									@Override
									public void onAnimationEnd(
											Animation animation) {
										mDao.delete(info.packageName);// 从数据库删除记录
										mLockedList.remove(info);// 从已加锁集合删除元素
										mUnlockList.add(info);// 给未加锁集合添加元素

										// 刷新listview
										mLockedAdapter.notifyDataSetChanged();
										mUnlockAdapter.notifyDataSetChanged();
									}
								});
					} else {
						view.startAnimation(mLockAnim);
						mLockAnim.setAnimationListener(new AnimationListener() {

							@Override
							public void onAnimationStart(Animation animation) {
							}

							@Override
							public void onAnimationRepeat(Animation animation) {
							}

							@Override
							public void onAnimationEnd(Animation animation) {
								mDao.add(info.packageName);// 向数据库添加记录
								mLockedList.add(info);// 给已加锁集合添加元素
								mUnlockList.remove(info);// 从未加锁集合删除元素
								// 刷新listview
								mLockedAdapter.notifyDataSetChanged();
								mUnlockAdapter.notifyDataSetChanged();
							}
						});
					}
				}
			});

			return convertView;
		}
	}

	static class ViewHolder {
		public ImageView ivIcon;
		public TextView tvName;
		public ImageView ivLock;
	}

}
