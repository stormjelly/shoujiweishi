package com.itheima.mobilesafeteach.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.service.AddressService;
import com.itheima.mobilesafeteach.service.BlackNumberService;
import com.itheima.mobilesafeteach.utils.PrefUtils;
import com.itheima.mobilesafeteach.utils.ServiceStatusUtils;
import com.itheima.mobilesafeteach.view.AddressDialog;
import com.itheima.mobilesafeteach.view.SettingItemView;

/**
 * 设置中心
 * 
 * @author Kevin
 * 
 */
public class SettingActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_setting);
		initUpdateSetting();
		initAddressSetting();
		initAddressStyle();
		initBlackNumberSetting();
	}

	/**
	 * 黑名单设置
	 */
	private void initBlackNumberSetting() {
		boolean serviceRunning = ServiceStatusUtils.isServiceRunning(this,
				BlackNumberService.class);

		final SettingItemView sivBalckNumber = (SettingItemView) findViewById(R.id.siv_black_number);

		sivBalckNumber.setToggleOn(serviceRunning);

		sivBalckNumber.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(SettingActivity.this,
						BlackNumberService.class);
				if (sivBalckNumber.isToggleOn()) {
					sivBalckNumber.setToggleOn(false);
					stopService(intent);
				} else {
					sivBalckNumber.setToggleOn(true);
					startService(intent);
				}
			}
		});
	}

	/**
	 * 自动更新设置
	 */
	private void initUpdateSetting() {
		final SettingItemView sivUpdate = (SettingItemView) findViewById(R.id.siv_update);
		boolean update = PrefUtils.getBoolean(this, "update", true);

		sivUpdate.setToggleOn(update);

		sivUpdate.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// if (sivUpdate.isToggleOn()) {
				// sivUpdate.setToggleOn(false);
				// edit.putBoolean("update", false);
				// } else {
				// sivUpdate.setToggleOn(true);
				// edit.putBoolean("update", true);
				// }

				sivUpdate.toggle();
				PrefUtils.putBoolean(SettingActivity.this, "update",
						sivUpdate.isToggleOn());
			}
		});
	}

	/**
	 * 归属地显示设置
	 */
	private void initAddressSetting() {
		boolean serviceRunning = ServiceStatusUtils.isServiceRunning(this,
				AddressService.class);

		final SettingItemView sivShowAddress = (SettingItemView) findViewById(R.id.siv_show_address);

		sivShowAddress.setToggleOn(serviceRunning);

		sivShowAddress.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(SettingActivity.this,
						AddressService.class);
				if (sivShowAddress.isToggleOn()) {
					sivShowAddress.setToggleOn(false);
					stopService(intent);
				} else {
					sivShowAddress.setToggleOn(true);
					startService(intent);
				}
			}
		});
	}

	/**
	 * 初始化归属地提示框风格
	 */
	private void initAddressStyle() {
		final SettingItemView scvStyle = (SettingItemView) findViewById(R.id.scv_address_style);

		scvStyle.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// 选择归属地样式的弹窗
				final AddressDialog dialog = new AddressDialog(
						SettingActivity.this);// 注意此处必须传递activity对象, 否则创建弹窗失败
				dialog.setAdapter(new AddressAdapter());
				dialog.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						PrefUtils.putInt(SettingActivity.this, "address_style",
								itmeBgs[position]);
						dialog.dismiss();
					}
				});

				dialog.show();
			}

		});
	}

	private String[] items = new String[] { "半透明", "活力橙", "卫士蓝", "金属灰", "苹果绿" };

	private int[] itmeBgs = new int[] { R.drawable.toast_address_normal,
			R.drawable.toast_address_orange, R.drawable.toast_address_blue,
			R.drawable.toast_address_gray, R.drawable.toast_address_green };

	// 归属地样式数据适配器
	class AddressAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			return items.length;
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view = View.inflate(getApplicationContext(),
					R.layout.item_address, null);
			ImageView ivAddressBg = (ImageView) view
					.findViewById(R.id.iv_address_bg);
			TextView tvAddressText = (TextView) view
					.findViewById(R.id.tv_address_text);
			ImageView ivAddressSelected = (ImageView) view
					.findViewById(R.id.iv_address_selected);

			ivAddressBg.setImageResource(itmeBgs[position]);
			tvAddressText.setText(items[position]);

			int style = PrefUtils.getInt(SettingActivity.this, "address_style",
					R.drawable.toast_address_normal);
			if (style == itmeBgs[position]) {
				ivAddressSelected.setVisibility(View.VISIBLE);
			} else {
				ivAddressSelected.setVisibility(View.INVISIBLE);
			}

			return view;
		}
	}
}
