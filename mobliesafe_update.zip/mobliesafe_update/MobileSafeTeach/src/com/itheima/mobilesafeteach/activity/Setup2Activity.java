package com.itheima.mobilesafeteach.activity;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.global.GlobalConstants;
import com.itheima.mobilesafeteach.utils.PrefUtils;

public class Setup2Activity extends BaseSetupActivity {

	private RelativeLayout rlBind;
	private ImageView ivLock;

	private TelephonyManager mTelePhonyManager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setup2);

		rlBind = (RelativeLayout) findViewById(R.id.rl_bind);
		ivLock = (ImageView) findViewById(R.id.iv_lock);

		String sim = PrefUtils.getString(this, GlobalConstants.PREF_SIM, null);

		if (!TextUtils.isEmpty(sim)) {
			ivLock.setImageResource(R.drawable.lock);
		} else {
			ivLock.setImageResource(R.drawable.unlock);
		}

		mTelePhonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
		rlBind.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String sim = PrefUtils.getString(getApplicationContext(),
						"sim", null);

				if (!TextUtils.isEmpty(sim)) {
					PrefUtils.remove(getApplicationContext(),
							GlobalConstants.PREF_SIM);// 删除sim序列号
					ivLock.setImageResource(R.drawable.unlock);
				} else {
					String simSerialNumber = mTelePhonyManager
							.getSimSerialNumber();// 获取sim卡序列号
					System.out.println("sim卡序列号:" + simSerialNumber);
					System.out.println("手机号码:"
							+ mTelePhonyManager.getLine1Number());
					PrefUtils.putString(getApplicationContext(),
							GlobalConstants.PREF_SIM, simSerialNumber);// 保存sim卡序列号

					ivLock.setImageResource(R.drawable.lock);
				}
			}
		});
	}

	@Override
	public void showNext() {
		String sim = PrefUtils.getString(this, GlobalConstants.PREF_SIM, null);
		if (TextUtils.isEmpty(sim)) {
			Toast.makeText(this, "必须先绑定sim卡!", Toast.LENGTH_SHORT).show();
			return;
		}

		Intent intent = new Intent(this, Setup3Activity.class);
		startActivity(intent);
		finish();

		overridePendingTransition(R.anim.trans_in, R.anim.trans_out);// Activity切换的动画效果
	}

	@Override
	public void showPrevious() {
		Intent intent = new Intent(this, Setup1Activity.class);
		startActivity(intent);
		finish();

		overridePendingTransition(R.anim.trans_pre_in, R.anim.trans_pre_out);// Activity切换的动画效果
	}
}
