package com.itheima.mobilesafeteach.activity;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.IPackageDataObserver;
import android.content.pm.IPackageStatsObserver;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.PackageStats;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.SystemClock;
import android.text.format.Formatter;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.itheima.mobilesafeteach.R;

/**
 * 缓存清理页面 需要权限:android.permission.GET_PACKAGE_SIZE
 * 
 * @author Kevin
 * 
 */
public class CleanCacheActivity extends Activity {

	private ArrayList<CacheInfo> mList;//扫描列表
	private ArrayList<CacheInfo> mCacheList;//有缓存的应用列表

	private ProgressBar pbProgress;
	private TextView tvName;
	private TextView tvCacheSize;
	private ImageView ivScanLine;
	private ImageView ivIcon;
	private LinearLayout llResult;
	private LinearLayout llProgress;
	private TextView tvResult;
	private Button btnClearAll;

	private PackageManager mPM;
	private ScanCacheTask mTask;

	private ListView lvList;
	private CacheAdapter mAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_clean_cache);
		pbProgress = (ProgressBar) findViewById(R.id.pb_progress);
		tvName = (TextView) findViewById(R.id.tv_name);
		tvCacheSize = (TextView) findViewById(R.id.tv_cache_size);
		lvList = (ListView) findViewById(R.id.lv_cache);
		ivScanLine = (ImageView) findViewById(R.id.iv_scan_line);
		ivIcon = (ImageView) findViewById(R.id.iv_icon);
		llResult = (LinearLayout) findViewById(R.id.ll_result);
		llProgress = (LinearLayout) findViewById(R.id.ll_progress);
		tvResult = (TextView) findViewById(R.id.tv_result);
		btnClearAll = (Button) findViewById(R.id.btn_clear_all);

		mPM = getPackageManager();
	}
	
	@Override
	protected void onStart() {
		super.onStart();
		startScan();
	}

	@Override
	protected void onPause() {
		super.onPause();
		if (mTask != null) {
			mTask.stop();
			mTask = null;
		}
	}

	/**
	 * 开始扫描
	 */
	private void startScan() {
		if (mTask != null) {
			mTask.stop();
			mTask = null;
		}

		mTask = new ScanCacheTask();
		mTask.execute();
	}

	class ScanCacheTask extends AsyncTask<Void, CacheInfo, Void> {

		int progress = 0;
		int totalCount = 0;

		boolean isStop = false;

		@Override
		protected void onPreExecute() {
			mList = new ArrayList<CleanCacheActivity.CacheInfo>();
			mCacheList = new ArrayList<CleanCacheActivity.CacheInfo>();
			mAdapter = new CacheAdapter();
			lvList.setAdapter(mAdapter);

			//初始化扫描动画, 注意:由于是相对父控件移动,所以使用Animation.RELATIVE_TO_PARENT
			TranslateAnimation anim = new TranslateAnimation(
					Animation.RELATIVE_TO_PARENT, 0,
					Animation.RELATIVE_TO_PARENT, 0,
					Animation.RELATIVE_TO_PARENT, 0,
					Animation.RELATIVE_TO_PARENT, 1);
			anim.setDuration(1000);
			anim.setRepeatMode(Animation.REVERSE);//动画执行结束后逆向再执行一遍
			anim.setRepeatCount(Animation.INFINITE);//无限循环
			ivScanLine.startAnimation(anim);

			llProgress.setVisibility(View.VISIBLE);
			llResult.setVisibility(View.GONE);

			//在扫描过程中禁用一键清理按钮
			btnClearAll.setEnabled(false);
		}

		@Override
		protected Void doInBackground(Void... params) {
			List<PackageInfo> packages = mPM
					.getInstalledPackages(PackageManager.GET_UNINSTALLED_PACKAGES);

			totalCount = packages.size();

			for (PackageInfo packageInfo : packages) {
				try {
					Method method = mPM.getClass().getMethod(
							"getPackageSizeInfo", String.class,
							IPackageStatsObserver.class);
					method.invoke(mPM, packageInfo.packageName,
							new MyObserver());
				} catch (Exception e) {
					e.printStackTrace();
				}

				progress++;

				SystemClock.sleep(200);

				if (isStop) {
					break;
				}
			}

			return null;
		}

		//更新扫描进度
		public void updateProgress(CacheInfo info) {
			publishProgress(info);
		}

		@Override
		protected void onProgressUpdate(CacheInfo... values) {
			if (isStop) {
				return;
			}

			if (progress % 3 == 0) {
				//刷新listview
				mAdapter.notifyDataSetChanged();
			}

			lvList.smoothScrollToPosition(mList.size() - 1);

			CacheInfo info = values[0];

			//更新进度条
			pbProgress.setProgress(progress * 100 / totalCount);
			tvName.setText(info.name);
			tvCacheSize.setText("缓存大小:"
					+ Formatter.formatFileSize(getApplicationContext(),
							info.cacheSize));
			ivIcon.setImageDrawable(info.icon);
		}

		@Override
		protected void onPostExecute(Void result) {
			if (isStop) {
				return;
			}

			mAdapter.notifyDataSetChanged();
			lvList.smoothScrollToPosition(0);
			ivScanLine.clearAnimation();//停止扫描线动画

			llProgress.setVisibility(View.GONE);
			llResult.setVisibility(View.VISIBLE);

			//计算总缓存大小
			int totalCache = 0;
			for (CacheInfo info : mCacheList) {
				totalCache += info.cacheSize;
			}

			//展示扫描结果
			tvResult.setText(String.format("总共有%d处缓存,共%s", mCacheList.size(),
					Formatter.formatFileSize(getApplicationContext(),
							totalCache)));

			//扫描结束后启用一键清理按钮
			btnClearAll.setEnabled(true);
		}

		public void stop() {
			isStop = true;
		}

	}

	/**
	 * 一键清理 需要权限: <uses-permission
	 * android:name="android.permission.CLEAR_APP_CACHE" />
	 * 
	 * @param view
	 */
	public void cleanAllCache(View view) {
		try {
			// 通过反射调用freeStorageAndNotify方法, 向系统申请内存
			Method method = mPM.getClass().getMethod("freeStorageAndNotify",
					long.class, IPackageDataObserver.class);
			// 参数传Long最大值, 这样可以保证系统将所有app缓存清理掉
			method.invoke(mPM, Long.MAX_VALUE, new IPackageDataObserver.Stub() {

				@Override
				public void onRemoveCompleted(String packageName,
						boolean succeeded) throws RemoteException {
					System.out.println("flag==" + succeeded);

					runOnUiThread(new Runnable() {
						public void run() {
							Toast.makeText(getApplicationContext(), "清理成功!",
									Toast.LENGTH_SHORT).show();
							startScan();//重新扫描
						}
					});
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 快速扫描
	 * @param view
	 */
	public void startRetry(View view) {
		startScan();
	}

	class MyObserver extends IPackageStatsObserver.Stub {

		// 在子线程运行
		@Override
		public void onGetStatsCompleted(PackageStats pStats, boolean succeeded)
				throws RemoteException {
			try {
				long cacheSize = pStats.cacheSize;// 获取缓存大小
				CacheInfo info = new CacheInfo();
				String packageName = pStats.packageName;
				info.packageName = packageName;

				ApplicationInfo applicationInfo = mPM.getApplicationInfo(
						packageName, 0);
				info.name = applicationInfo.loadLabel(mPM).toString();
				info.icon = applicationInfo.loadIcon(mPM);
				info.cacheSize = cacheSize;

				if (info.cacheSize > 0) {//发现缓存
					mList.add(0, info);//添加到整体集合的第一个位置
					mCacheList.add(info);//添加到缓存集合中
				} else {
					mList.add(info);
				}

				mTask.updateProgress(info);//更新进度
			} catch (NameNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	class CacheAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			return mList.size();
		}

		@Override
		public CacheInfo getItem(int position) {
			return mList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
				convertView = View.inflate(getApplicationContext(),
						R.layout.list_cacheinfo_item, null);
				holder = new ViewHolder();
				holder.tvName = (TextView) convertView
						.findViewById(R.id.tv_name);
				holder.tvCacheSize = (TextView) convertView
						.findViewById(R.id.tv_cache_size);
				holder.ivIcon = (ImageView) convertView
						.findViewById(R.id.iv_icon);
				holder.ivDelete = (ImageView) convertView
						.findViewById(R.id.iv_delete);

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			final CacheInfo item = getItem(position);

			holder.tvName.setText(item.name);
			holder.ivIcon.setImageDrawable(item.icon);
			holder.tvCacheSize.setText("缓存大小:"
					+ Formatter.formatFileSize(getApplicationContext(),
							item.cacheSize));

			if (item.cacheSize > 0) {
				holder.ivDelete.setVisibility(View.VISIBLE);
				holder.ivDelete.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						//启动到某个系统应用页面
						Intent intent = new Intent();
						intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
						intent.addCategory(Intent.CATEGORY_DEFAULT);//有无没影响
						intent.setData(Uri.parse("package:" + item.packageName));
						startActivity(intent);
					}
				});
			} else {
				holder.ivDelete.setVisibility(View.GONE);
			}

			return convertView;
		}

	}

	static class ViewHolder {
		public TextView tvName;
		public TextView tvCacheSize;
		public ImageView ivIcon;
		public ImageView ivDelete;
	}

	// 缓存对象的封装
	class CacheInfo {
		public String name;
		public String packageName;
		public Drawable icon;
		public long cacheSize;
	}

}
