package com.itheima.mobilesafeteach.activity;

import java.util.ArrayList;
import java.util.List;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.github.lzyzsd.circleprogress.ArcProgress;
import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.db.dao.AntiVirusDao;
import com.itheima.mobilesafeteach.utils.MD5Utils;

/**
 * 手机杀毒
 * 
 * @author Kevin
 * 
 */
public class AntiVirusActivity extends Activity {

	private ArrayList<ScanInfo> mScanList;//扫描列表
	private ArrayList<ScanInfo> mVirusList;//病毒列表

	private ListView lvList;
	private ArcProgress apProgress;
	private TextView tvPackageName;
	private TextView tvResult;
	private ImageView ivLeft;
	private ImageView ivRight;
	private LinearLayout llProgress;
	private LinearLayout llResult;
	private LinearLayout llAnimator;
	private Button btnRetry;

	private ScanAdapter mAdapter;

	private ScanTask mTask;

	//开门大吉左侧和右侧图片对象
	private Bitmap mLeftBitmap;
	private Bitmap mRightBitmap;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_anti_virus);
		lvList = (ListView) findViewById(R.id.lv_anti_virus);
		apProgress = (ArcProgress) findViewById(R.id.ap_progress);
		tvPackageName = (TextView) findViewById(R.id.tv_package_name);
		ivLeft = (ImageView) findViewById(R.id.iv_left);
		ivRight = (ImageView) findViewById(R.id.iv_right);
		llProgress = (LinearLayout) findViewById(R.id.ll_progress);
		llResult = (LinearLayout) findViewById(R.id.ll_result);
		tvResult = (TextView) findViewById(R.id.tv_result);
		llAnimator = (LinearLayout) findViewById(R.id.ll_animator);
		btnRetry = (Button) findViewById(R.id.btn_retry);
	}
	
	@Override
	protected void onStart() {
		super.onStart();
		startScan();
	}

	/**
	 * 开始扫描
	 */
	private void startScan() {
		//如果异步任务不为空, 停止当前任务
		if (mTask != null) {
			mTask.stop();
			mTask = null;
		}

		//启动新的异步任务
		mTask = new ScanTask();
		mTask.execute();
	}

	@Override
	protected void onPause() {
		super.onPause();
		//如果异步任务不为空, 停止当前任务
		if (mTask != null) {
			mTask.stop();
			mTask = null;
		}
	}

	class ScanTask extends AsyncTask<Void, ScanInfo, Void> {

		private int totalNum;//带扫描app总数

		private int progress;//扫描进度

		private boolean isStop;//标记是否停止扫描

		@Override
		protected void onPreExecute() {
			mScanList = new ArrayList<AntiVirusActivity.ScanInfo>();//初始化扫描集合
			mVirusList = new ArrayList<AntiVirusActivity.ScanInfo>();//初始化病毒集合
			//为扫描列表设置数据
			mAdapter = new ScanAdapter();
			lvList.setAdapter(mAdapter);

			//隐藏开门动画布局
			llAnimator.setVisibility(View.GONE);
			//显示扫描进度布局
			llProgress.setVisibility(View.VISIBLE);
			//隐藏扫描结果布局
			llResult.setVisibility(View.GONE);
		}

		@Override
		protected Void doInBackground(Void... params) {
			PackageManager pm = getPackageManager();
			// 获取所有已安装/未安装的包的安装包信息
			List<PackageInfo> packages = pm
					.getInstalledPackages(PackageManager.GET_UNINSTALLED_PACKAGES);

			totalNum = packages.size();

			for (PackageInfo packageInfo : packages) {
				progress++;

				String name = packageInfo.applicationInfo.loadLabel(pm)
						.toString();
				Drawable icon = packageInfo.applicationInfo.loadIcon(pm);

				String apkPath = packageInfo.applicationInfo.sourceDir;
				String md5 = MD5Utils.getFileMd5(apkPath);//根据apk文件路径计算该文件md5
				boolean isVirus = AntiVirusDao.isVirus(getApplicationContext(),
						md5);//判断是否是病毒

				//初始化扫描对象
				ScanInfo scanInfo = new ScanInfo();
				scanInfo.name = name;
				scanInfo.packageName = packageInfo.packageName;
				scanInfo.icon = icon;

				if (isVirus) {
					// 是病毒
					scanInfo.isVirus = true;
					//如果是病毒,添加在第一个位置
					mScanList.add(0, scanInfo);

					mVirusList.add(scanInfo);
				} else {
					// 不是病毒
					scanInfo.isVirus = false;
					mScanList.add(scanInfo);
				}

				SystemClock.sleep(200);

				//更新进度
				publishProgress(scanInfo);

				if (isStop) {
					break;
				}
			}

			return null;
		}

		@Override
		protected void onProgressUpdate(ScanInfo... values) {
			if (isStop) {
				return;
			}

			if (progress % 3 == 0) {
				//刷新listview
				mAdapter.notifyDataSetChanged();
			}

			lvList.smoothScrollToPosition(mAdapter.getCount() - 1);//listview滑动到最后一个item的位置

			//更新进度
			apProgress.setProgress((int) (progress * 100f / totalNum + 0.5f));
			//更新包名
			tvPackageName.setText(values[0].packageName);
		}

		@Override
		protected void onPostExecute(Void result) {
			if (isStop) {
				return;
			}

			//刷新listview
			mAdapter.notifyDataSetChanged();
			lvList.smoothScrollToPosition(0);//listview重新滑动到顶部

			llProgress.setVisibility(View.GONE);//隐藏进度布局
			llResult.setVisibility(View.VISIBLE);//展示扫描结果界面
			llAnimator.setVisibility(View.VISIBLE);//显示开门动画布局

			if (mVirusList.isEmpty()) {
				tvResult.setText("您的手机很安全");
			} else {
				tvResult.setText("您的手机很不安全");
			}

			//开门大吉动画
			llProgress.setDrawingCacheEnabled(true);//开启绘制缓存,目的是为了获取最终绘制的图片对象
			llProgress.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);//设置图片质量
			Bitmap bitmap = llProgress.getDrawingCache();//获取绘制结束之后的图片对象

			//设置开门动画左侧图片
			mLeftBitmap = getLeftBitmap(bitmap);
			ivLeft.setImageBitmap(mLeftBitmap);

			//设置开门动画右侧图片
			mRightBitmap = getRightBitmap(bitmap);
			ivRight.setImageBitmap(mRightBitmap);

			showOpenAnimator();
		}

		public void stop() {
			isStop = true;
		}
	}

	/**
	 * 展示开门大吉动画
	 */
	private void showOpenAnimator() {
		//1.左侧图片左移消失
		//2.右侧图片右移消失
		//3.左侧图片渐变消失
		//4.右侧图片渐变消失
		//5.结果界面渐变展示
		//ivLeft.setTranslationX(translationX)
		//ivLeft.setAlpha(alpha)
		btnRetry.setEnabled(false);//启动动画时, 禁用重新扫描按钮
		AnimatorSet set = new AnimatorSet();
		set.playTogether(
				ObjectAnimator.ofFloat(ivLeft, "translationX", 0,
						-mLeftBitmap.getWidth()),
				ObjectAnimator.ofFloat(ivRight, "translationX", 0,
						mRightBitmap.getWidth()),
				ObjectAnimator.ofFloat(ivLeft, "alpha", 1, 0),
				ObjectAnimator.ofFloat(ivRight, "alpha", 1, 0),
				ObjectAnimator.ofFloat(llResult, "alpha", 0, 1));
		set.setDuration(3000);//设置动画时长
		set.addListener(new AnimatorListener() {

			@Override
			public void onAnimationStart(Animator animation) {

			}

			@Override
			public void onAnimationRepeat(Animator animation) {

			}

			@Override
			public void onAnimationEnd(Animator animation) {
				btnRetry.setEnabled(true);//动画结束之后, 启用按钮点击
			}

			@Override
			public void onAnimationCancel(Animator animation) {

			}
		});
		set.start();//启动动画
	}

	/**
	 * 获取开门动画左侧图片
	 */
	private Bitmap getLeftBitmap(Bitmap srcBitmap) {
		int width = (int) (srcBitmap.getWidth() / 2f + 0.5f);//计算左侧图片宽度
		//根据宽高创建一张空的图片
		Bitmap desBitmap = Bitmap.createBitmap(width, srcBitmap.getHeight(),
				srcBitmap.getConfig());

		//创建画布
		Canvas canvas = new Canvas(desBitmap);
		//在画布上绘制图片
		canvas.drawBitmap(srcBitmap, new Matrix(), null);

		return desBitmap;
	}

	/**
	 * 获取开门动画右侧图片
	 */
	private Bitmap getRightBitmap(Bitmap srcBitmap) {
		int width = (int) (srcBitmap.getWidth() / 2f + 0.5f);//计算左侧图片宽度
		//根据宽高创建一张空的图片
		Bitmap desBitmap = Bitmap.createBitmap(width, srcBitmap.getHeight(),
				srcBitmap.getConfig());

		//创建画布
		Canvas canvas = new Canvas(desBitmap);
		//在画布上绘制图片
		Matrix matrix = new Matrix();
		matrix.postTranslate(-width, 0);//左移半个图片宽度位置
		canvas.drawBitmap(srcBitmap, matrix, null);

		return desBitmap;
	}

	/**
	 * 重新扫描
	 */
	public void startRetry(View view) {
		//1.左侧图片右移显示
		//2.右侧图片左移显示
		//3.左侧图片渐变显示
		//4.右侧图片渐变显示
		//5.结果界面渐变消失
		//ivLeft.setTranslationX(translationX)
		//ivLeft.setAlpha(alpha)
		btnRetry.setEnabled(false);//启动动画时, 禁用重新扫描按钮
		AnimatorSet set = new AnimatorSet();
		set.playTogether(
				ObjectAnimator.ofFloat(ivLeft, "translationX",
						-mLeftBitmap.getWidth(), 0),
				ObjectAnimator.ofFloat(ivRight, "translationX",
						mRightBitmap.getWidth(), 0),
				ObjectAnimator.ofFloat(ivLeft, "alpha", 0, 1),
				ObjectAnimator.ofFloat(ivRight, "alpha", 0, 1),
				ObjectAnimator.ofFloat(llResult, "alpha", 1, 0));
		set.setDuration(3000);

		set.addListener(new AnimatorListener() {

			@Override
			public void onAnimationStart(Animator animation) {

			}

			@Override
			public void onAnimationRepeat(Animator animation) {

			}

			@Override
			public void onAnimationEnd(Animator animation) {
				startScan();
			}

			@Override
			public void onAnimationCancel(Animator animation) {

			}
		});

		set.start();
	}

	class ScanInfo {
		public String packageName;
		public String name;
		public boolean isVirus;
		public Drawable icon;
	}

	class ScanAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			return mScanList.size();
		}

		@Override
		public ScanInfo getItem(int position) {
			return mScanList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
				convertView = View.inflate(getApplicationContext(),
						R.layout.list_anti_virus_item, null);
				holder = new ViewHolder();
				holder.tvName = (TextView) convertView
						.findViewById(R.id.tv_name);
				holder.tvStatus = (TextView) convertView
						.findViewById(R.id.tv_status);
				holder.ivIcon = (ImageView) convertView
						.findViewById(R.id.iv_icon);

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			ScanInfo item = getItem(position);

			holder.tvName.setText(item.name);

			if (item.isVirus) {
				holder.tvStatus.setText("病毒");
				holder.tvStatus.setTextColor(Color.RED);
			} else {
				holder.tvStatus.setText("安全");
				holder.tvStatus.setTextColor(Color.GREEN);
			}

			holder.ivIcon.setImageDrawable(item.icon);

			return convertView;
		}

	}

	static class ViewHolder {
		public TextView tvName;
		public TextView tvStatus;
		public ImageView ivIcon;
	}
}
