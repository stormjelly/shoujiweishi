package com.itheima.mobilesafeteach.activity;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

public abstract class BaseSetupActivity extends Activity {

	private GestureDetector mDetector;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		mDetector = new GestureDetector(this,
				new GestureDetector.SimpleOnGestureListener() {
					@Override
					public boolean onFling(MotionEvent e1, MotionEvent e2,
							float velocityX, float velocityY) {

						if (Math.abs(e1.getRawY() - e2.getRawY()) > 100) {
							Toast.makeText(BaseSetupActivity.this, "不能这样划哦!",
									Toast.LENGTH_SHORT).show();
							return true;
						}
						
						if (Math.abs(velocityX) < 100) {
							Toast.makeText(BaseSetupActivity.this, "速度太慢啦!",
									Toast.LENGTH_SHORT).show();
							return true;
						}
						
						if (e2.getRawX() - e1.getRawX() > 200) {
							Log.d("Test", "显示上一页");
							showPrevious();
							return true;
						}

						if (e1.getRawX() - e2.getRawX() > 200) {
							Log.d("Test", "显示下一页");
							showNext();
							return true;
						}

						return super.onFling(e1, e2, velocityX, velocityY);
					}
				});
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		mDetector.onTouchEvent(event);
		return super.onTouchEvent(event);
	}

	// 展示下一页
	public abstract void showNext();

	// 展示上一页
	public abstract void showPrevious();

	// 下一页按钮点击
	public void next(View view) {
		showNext();
	}

	// 上一页按钮点击
	public void previous(View view) {
		showPrevious();
	}
}
