package com.itheima.mobilesafeteach.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.global.GlobalConstants;
import com.itheima.mobilesafeteach.utils.PrefUtils;

public class Setup5Activity extends BaseSetupActivity {

	private CheckBox cbProtect;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setup5);
		cbProtect = (CheckBox) findViewById(R.id.cb_protect);

		boolean protecting = PrefUtils.getBoolean(this, GlobalConstants.PREF_IS_PROTECTING, false);
		cbProtect.setChecked(protecting);

		cbProtect.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				PrefUtils.putBoolean(getApplicationContext(), GlobalConstants.PREF_IS_PROTECTING,
						isChecked);// 更新sp状态
			}
		});
	}

	@Override
	public void showNext() {
		PrefUtils.putBoolean(this, GlobalConstants.PREF_IS_CONFIG, true);// 记录已经设置的状态

		// 进入手机防盗主页面
		Intent intent = new Intent(this, LostFindActivity.class);
		startActivity(intent);
		finish();

		overridePendingTransition(R.anim.trans_in, R.anim.trans_out);// Activity切换的动画效果
	}

	@Override
	public void showPrevious() {
		Intent intent = new Intent(this, Setup3Activity.class);
		startActivity(intent);
		finish();

		overridePendingTransition(R.anim.trans_pre_in, R.anim.trans_pre_out);// Activity切换的动画效果
	}
}
