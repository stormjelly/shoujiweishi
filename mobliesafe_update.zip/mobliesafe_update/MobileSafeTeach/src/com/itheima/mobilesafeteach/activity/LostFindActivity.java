package com.itheima.mobilesafeteach.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.global.GlobalConstants;
import com.itheima.mobilesafeteach.utils.PrefUtils;

/**
 * 手机防盗页面
 * 
 * @author Kevin
 * 
 */
public class LostFindActivity extends Activity {

	private ImageView ivProtect;
	private TextView tvSafePhone;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		boolean isConfiged = PrefUtils.getBoolean(this,
				GlobalConstants.PREF_IS_CONFIG, false);

		// 判断是否已经配置了设置向导, 如果没有配置,先跳转到配置页面
		if (isConfiged) {
			setContentView(R.layout.activity_lost_find);
			ivProtect = (ImageView) findViewById(R.id.iv_protecting);
			tvSafePhone = (TextView) findViewById(R.id.tv_safe_phone);

			// 判断防盗保护是否开启,更新图标状态
			boolean protecting = PrefUtils.getBoolean(this,
					GlobalConstants.PREF_IS_PROTECTING, false);
			if (protecting) {
				ivProtect.setImageResource(R.drawable.lock);
			} else {
				ivProtect.setImageResource(R.drawable.unlock);
			}

			tvSafePhone.setText(PrefUtils.getString(this,
					GlobalConstants.PREF_SAFE_PHONE, ""));// 更新安全号码
		} else {
			Intent intent = new Intent(this, Setup1Activity.class);
			startActivity(intent);
			finish();
		}
	}

	// 重新进入设置页面
	public void resetConfig(View view) {
		Intent intent = new Intent(this, Setup1Activity.class);
		startActivity(intent);
		finish();
	}

	// 防盗保护开关设置
	public void toggleProtect(View view) {
		boolean protecting = PrefUtils.getBoolean(this,
				GlobalConstants.PREF_IS_PROTECTING, false);

		if (protecting) {// 如果当前状态为开启, 则关闭
			ivProtect.setImageResource(R.drawable.unlock);
			PrefUtils.putBoolean(this, GlobalConstants.PREF_IS_PROTECTING,
					false);
		} else {// 如果当前状态为关闭, 则开启
			ivProtect.setImageResource(R.drawable.lock);
			PrefUtils
					.putBoolean(this, GlobalConstants.PREF_IS_PROTECTING, true);
		}
	}

}
