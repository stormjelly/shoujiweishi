package com.itheima.mobilesafeteach.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.TextView;
import android.widget.Toast;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.service.ProtectService;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;

/**
 * 闪屏页面
 * 
 * @author Kevin
 * 
 */
public class SplashActivity extends Activity {

	private static final String TAG = SplashActivity.class.getSimpleName();

	public static final int ENTER_HOME = 1;

	TextView tvVersion;
	View rlRoot;

	private String mDownloadUrl;// apk下载地址
	private String mDescription;// 版本描述
	private String mVersionName;// 版本名称

	private Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case ENTER_HOME:
				enterHome();
				break;
			default:
				break;
			}
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);

		tvVersion = (TextView) findViewById(R.id.tv_version);
		tvVersion.setText(getVersionName());

		rlRoot = findViewById(R.id.rl_root);

		SharedPreferences sp = getSharedPreferences("config", MODE_PRIVATE);
		boolean update = sp.getBoolean("update", true);

		copyDB("address.db");// 拷贝归属地数据库
		copyDB("commonnum.db");// 拷贝常用号码数据库
		copyDB("antivirus.db");// 拷贝病毒数据库

		if (update) {
			checkVersion();
		} else {
			Log.d(TAG, "not check version");
			mHandler.sendEmptyMessageDelayed(ENTER_HOME, 2000);
		}

		// 开启渐变动画
		AlphaAnimation anim = new AlphaAnimation(0.3f, 1f);
		anim.setDuration(2000);
		rlRoot.startAnimation(anim);

		createShortcut();

		//开启保护服务
		startService(new Intent(this, ProtectService.class));
	}

	/**
	 * 拷贝数据库
	 */
	private void copyDB(String dbName) {
		File file = new File(getFilesDir(), dbName);// 目的文件

		if (file.exists()) {
			System.out.println("数据库" + dbName + "已存在,无须拷贝!");
			return;
		}

		FileOutputStream out = null;
		InputStream in = null;
		try {
			out = new FileOutputStream(file);
			in = getAssets().open(dbName);// 源文件

			int len = 0;
			byte[] buffer = new byte[1024];
			while ((len = in.read(buffer)) > 0) {
				out.write(buffer, 0, len);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				out.close();
				in.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// 获取版本信息
	private String getVersionName() {
		PackageManager pm = getPackageManager();
		try {
			PackageInfo info = pm.getPackageInfo(getPackageName(), 0);
			String versionName = info.versionName;
			int versionCode = info.versionCode;
			Log.d(TAG, "versionName=" + versionName + "; versionCode="
					+ versionCode);
			return versionName;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return "";
	}

	// 获取版本码
	private int getVersionCode() {
		PackageManager pm = getPackageManager();
		try {
			PackageInfo info = pm.getPackageInfo(getPackageName(), 0);
			int versionCode = info.versionCode;
			return versionCode;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return 0;
	}

	//检测版本信息
	private void checkVersion() {
		HttpUtils utils = new HttpUtils();
		utils.configTimeout(5000);//设置连接超时
		utils.configSoTimeout(5000);//设置读取超时
		utils.send(HttpMethod.GET, "http://10.0.2.2:8080/update.json",
				new RequestCallBack<String>() {

					@Override
					public void onFailure(HttpException error, String msg) {
						error.printStackTrace();
						Toast.makeText(SplashActivity.this, "网络异常",
								Toast.LENGTH_SHORT).show();
						enterHome();
					}

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						String result = responseInfo.result;

						try {
							JSONObject json = new JSONObject(result);
							mVersionName = json.optString("versionName", null);
							int versionCode = json.getInt("versionCode");
							mDescription = json.optString("description");
							mDownloadUrl = json.getString("downloadUrl");

							Log.d(TAG, "description:" + mDescription);

							if (getVersionCode() < versionCode) {
								// 需要升级
								showUpdateDialog();
							} else {
								//延时两秒后跳到主页面
								mHandler.sendEmptyMessageDelayed(ENTER_HOME,
										2000);
							}
						} catch (JSONException e) {
							e.printStackTrace();
							Toast.makeText(SplashActivity.this, "Json解析错误",
									Toast.LENGTH_SHORT).show();
							enterHome();
						}
					}
				});
	}

	// 升级弹窗
	private void showUpdateDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("发现新版本:" + mVersionName);
		builder.setMessage(mDescription);
		// builder.setCancelable(false);//流氓手段,让用户点击返回键没有作用, 不建议采纳
		// 点击物理返回键,监听弹窗被取消的事件
		builder.setOnCancelListener(new OnCancelListener() {

			@Override
			public void onCancel(DialogInterface dialog) {
				enterHome();
			}
		});

		builder.setPositiveButton("立即更新", new OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				showProgressDialog();
			}
		});

		builder.setNegativeButton("以后再说", new OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				enterHome();
			}
		});

		AlertDialog dialog = builder.create();
		dialog.show();
	}

	/**
	 * 展示下载进度弹窗
	 */
	protected void showProgressDialog() {
		final ProgressDialog dialog = new ProgressDialog(this);
		dialog.setCancelable(false);//弹窗不可取消
		dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);// 水平方向进度条,用于展示进度
		dialog.setTitle("下载进度");
		dialog.show();

		// 检查是否已挂载sdcard
		if (Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) {
			String localPath = Environment.getExternalStorageDirectory()
					+ "/update.apk";

			// 下载apk
			HttpUtils hu = new HttpUtils();
			hu.download(mDownloadUrl, localPath, new RequestCallBack<File>() {

				@Override
				public void onLoading(long total, long current,
						boolean isUploading) {
					Log.d(TAG, "onLoading:" + current + "/" + total);
					int percent = (int) (current * 100 / total);
					//更新进度弹窗的进度条
					dialog.setProgress(percent);
				}

				@Override
				public void onSuccess(ResponseInfo<File> responseInfo) {
					Log.d(TAG,
							"onSuccess:"
									+ responseInfo.result.getAbsolutePath());
					//下载成功后弹窗消失
					dialog.dismiss();

					// 安装apk
					Intent intent = new Intent();
					intent.setAction(Intent.ACTION_VIEW);
					intent.addCategory(Intent.CATEGORY_DEFAULT);
					intent.setDataAndType(Uri.fromFile(responseInfo.result),
							"application/vnd.android.package-archive");
					startActivityForResult(intent, 0);
				}

				@Override
				public void onFailure(HttpException error, String msg) {
					//下载失败后弹窗消失

					Toast.makeText(SplashActivity.this, "下载失败!",
							Toast.LENGTH_SHORT).show();
					enterHome();
				}
			});

		} else {
			Toast.makeText(SplashActivity.this, "没有找到sdcard!",
					Toast.LENGTH_SHORT).show();
			enterHome();
		}

	}

	// 进入主页面
	private void enterHome() {
		startActivity(new Intent(this, HomeActivity.class));
		finish();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		enterHome();
	}

	// 创建快捷方式
	// 需要权限: <uses-permission
	// android:name="com.android.launcher.permission.INSTALL_SHORTCUT"/>
	private void createShortcut() {
		SharedPreferences sp = getSharedPreferences("config", MODE_PRIVATE);
		boolean created = sp.getBoolean("is_shortcut_created", false);

		if (!created) {// 如果没创建,才开始创建,否则会创建多个快捷方式
			Intent intent = new Intent(
					"com.android.launcher.action.INSTALL_SHORTCUT");
			// 应用名称
			intent.putExtra(Intent.EXTRA_SHORTCUT_NAME, "黑马卫士");

			// 应用图标
			intent.putExtra(Intent.EXTRA_SHORTCUT_ICON, BitmapFactory
					.decodeResource(getResources(), R.drawable.home_apps));

			// 不允许重复
			intent.putExtra("duplicate", false);

			// 应用动作
			Intent actionIntent = new Intent();
			actionIntent.setAction("com.itheima.mobilesafe.home");// 设置action,
																	// 需要在清单文件中配置
			actionIntent.addCategory(Intent.CATEGORY_DEFAULT);
			intent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, actionIntent);

			// 发送广播
			sendBroadcast(intent);
			sp.edit().putBoolean("is_shortcut_created", true).commit();
		}
	}
}
