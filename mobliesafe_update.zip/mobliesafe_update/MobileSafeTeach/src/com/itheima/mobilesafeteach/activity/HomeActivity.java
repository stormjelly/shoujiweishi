package com.itheima.mobilesafeteach.activity;

import java.util.ArrayList;

import net.youmi.android.AdManager;
import net.youmi.android.banner.AdSize;
import net.youmi.android.banner.AdView;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.domain.HomeItemInfo;
import com.itheima.mobilesafeteach.global.GlobalConstants;
import com.itheima.mobilesafeteach.utils.MD5Utils;
import com.itheima.mobilesafeteach.utils.PrefUtils;

public class HomeActivity extends Activity {

	private GridView gvHome;
	private ImageView ivLogo;
	private ImageView ivSetting;

	private ArrayList<HomeItemInfo> mList;

	private String[] items = new String[] { "手机防盗", "通讯卫士", "软件管理", "进程管理",
			"流量统计", "手机杀毒", "缓存清理", "高级工具" };

	private Integer[] icons = new Integer[] { R.drawable.sjfd, R.drawable.srlj,
			R.drawable.rjgj, R.drawable.jcgl, R.drawable.lltj, R.drawable.sjsd,
			R.drawable.hcql, R.drawable.cygj };

	private String[] descs = new String[] { "远程定位手机", "全面拦截骚扰", "管理您的软件",
			"管理运行进程", "流量一目了然", "病毒无处藏身", "系统快如火箭", "工具大全" };

	private AlertDialog dialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		//初始化广告sdk
		AdManager.getInstance(this).init("b3609dc70688ba18", "571d125c17b2a994", true);

		gvHome = (GridView) findViewById(R.id.gv_home);
		ivLogo = (ImageView) findViewById(R.id.iv_logo);
		initData();

		startLogoAnim();

		ivSetting = (ImageView) findViewById(R.id.iv_setting);
		ivSetting.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// 进入设置中心
				startActivity(new Intent(HomeActivity.this,
						SettingActivity.class));
			}
		});
		
		// 实例化广告条
		AdView adView = new AdView(this, AdSize.FIT_SCREEN);
		// 获取要嵌入广告条的布局
		LinearLayout adLayout=(LinearLayout)findViewById(R.id.adLayout);
		// 将广告条加入到布局中
		adLayout.addView(adView);
	}

	//开启logo旋转动画
	private void startLogoAnim() {
		// ivLogo.setRotationY(rotationY);//通过设置RotationY,可以使图片沿着Y轴进行旋转
		// 开启属性动画
		ObjectAnimator anim = ObjectAnimator.ofFloat(ivLogo, "rotationY", 0,
				360);// 参1:要执行动画的对象; 参2:要修改的属性名称;参3-6:属性的值, 从0变化到360
		anim.setDuration(2000);// 动画持续时间
		anim.setRepeatCount(ObjectAnimator.INFINITE);// 重复次数,无限次
		anim.setRepeatMode(ObjectAnimator.REVERSE);// 重复模式:反转模式(正向执行一次后再逆向执行一次)
		anim.start();// 启动动画
	}

	//初始化数据
	private void initData() {
		//首页8个item数据
		mList = new ArrayList<HomeItemInfo>();
		for (int i = 0; i < items.length; i++) {
			HomeItemInfo info = new HomeItemInfo();
			info.iconId = icons[i];
			info.name = items[i];
			info.desc = descs[i];

			mList.add(info);
		}

		//给GridView设置数据
		gvHome.setAdapter(new HomeAdapter());

		gvHome.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				switch (position) {
				case 0:
					// 进入手机防盗
					showLostAndFindDialog();
					break;
				case 1:
					// 进入黑名单管理
					startActivity(new Intent(HomeActivity.this,
							BlackNumberActivity.class));
					break;
				case 2:
					// 进入应用管理
					startActivity(new Intent(HomeActivity.this,
							AppManagerActivity.class));
					break;
				case 3:
					// 进入进程管理
					startActivity(new Intent(HomeActivity.this,
							ProcessManagerActivity.class));
					break;
				case 4:
					// 进入流量统计
					startActivity(new Intent(HomeActivity.this,
							TrafficeMangerActivity.class));
					break;
				case 5:
					// 进入手机杀毒
					startActivity(new Intent(HomeActivity.this,
							AntiVirusActivity.class));
					break;
				case 6:
					// 进入缓存清理
					startActivity(new Intent(HomeActivity.this,
							CleanCacheActivity.class));
					break;
				case 7:
					// 进入高级工具
					startActivity(new Intent(HomeActivity.this,
							CommonToolsActivity.class));
					break;
				default:
					break;
				}
			}
		});

	}

	/**
	 * 显示手机防盗对话框
	 */
	private void showLostAndFindDialog() {
		if (isPasswordSet()) {
			// 弹出输入密码弹窗
			showEnterDialog();
		} else {
			// 弹出设置密码弹窗
			showSetPassDialog();
		}
	}

	/**
	 * 手机防盗密码输入对话框
	 */
	private void showEnterDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		View view = View.inflate(this, R.layout.dialog_input_password, null);
		final EditText etPass = (EditText) view.findViewById(R.id.et_password);

		Button btnOK = (Button) view.findViewById(R.id.btn_ok);
		Button btnCancel = (Button) view.findViewById(R.id.btn_cancel);

		btnOK.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String password = etPass.getText().toString();

				if (!TextUtils.isEmpty(password)) {
					String savedPass = PrefUtils.getString(
							getApplicationContext(),
							GlobalConstants.PREF_PASSWORD, null);
					if (MD5Utils.getMd5(password).equals(savedPass)) {
						// 跳转到手机防盗页
						startActivity(new Intent(HomeActivity.this,
								LostFindActivity.class));
						dialog.dismiss();
					} else {
						Toast.makeText(HomeActivity.this, "密码错误!",
								Toast.LENGTH_SHORT).show();
					}
				} else {
					Toast.makeText(HomeActivity.this, "密码不能为空",
							Toast.LENGTH_SHORT).show();
				}
			}
		});

		btnCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		// builder.setView(view);
		dialog = builder.create();
		dialog.setView(view);
		dialog.show();
	}

	/**
	 * 手机防盗密码设置对话框
	 */
	private void showSetPassDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		View view = View.inflate(this, R.layout.dialog_set_password, null);
		final EditText etPass = (EditText) view.findViewById(R.id.et_password);
		final EditText etPassConfirm = (EditText) view
				.findViewById(R.id.et_password_confirm);
		Button btnOK = (Button) view.findViewById(R.id.btn_ok);
		Button btnCancel = (Button) view.findViewById(R.id.btn_cancel);

		btnOK.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String password = etPass.getText().toString();
				String passConfirm = etPassConfirm.getText().toString();

				if (!TextUtils.isEmpty(password)
						&& !TextUtils.isEmpty(passConfirm)) {
					if (password.equals(passConfirm)) {
						PrefUtils.putString(getApplicationContext(),
								GlobalConstants.PREF_PASSWORD,
								MD5Utils.getMd5(password));// 更新sp
						// 跳转到手机防盗页
						startActivity(new Intent(HomeActivity.this,
								LostFindActivity.class));
						dialog.dismiss();
					} else {
						Toast.makeText(HomeActivity.this, "两次密码不一致",
								Toast.LENGTH_SHORT).show();
					}
				} else {
					Toast.makeText(HomeActivity.this, "密码不能为空",
							Toast.LENGTH_SHORT).show();
				}
			}
		});

		btnCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		// builder.setView(view);
		dialog = builder.create();
		dialog.setView(view);
		dialog.show();
	}

	/**
	 * 检测是否已经设置了手机防盗密码
	 * 
	 * @return
	 */
	private boolean isPasswordSet() {
		String password = PrefUtils.getString(this,
				GlobalConstants.PREF_PASSWORD, null);
		if (password != null) {
			return true;
		}

		return false;
	}

	class HomeAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			return mList.size();
		}

		@Override
		public HomeItemInfo getItem(int position) {
			return mList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view = View.inflate(HomeActivity.this,
					R.layout.list_home_item, null);
			ImageView ivItem = (ImageView) view.findViewById(R.id.iv_item);
			TextView tvItem = (TextView) view.findViewById(R.id.tv_name);
			TextView tvDesc = (TextView) view.findViewById(R.id.tv_desc);

			HomeItemInfo info = getItem(position);

			tvItem.setText(info.name);
			tvDesc.setText(info.desc);
			ivItem.setImageResource(info.iconId);

			return view;
		}

	}
}
