package com.itheima.mobilesafeteach.activity;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.receiver.AdminReceiver;

public class Setup4Activity extends BaseSetupActivity {

	private static final int REQUEST_CODE_ENABLE_ADMIN = 1010;

	private DevicePolicyManager mDPM;
	private ComponentName who;

	private RelativeLayout rlActive;
	private ImageView ivStatus;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setup4);

		rlActive = (RelativeLayout) findViewById(R.id.rl_active);
		ivStatus = (ImageView) findViewById(R.id.iv_active_status);

		// 根据当前激活状态,更新ui
		mDPM = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
		who = new ComponentName(this, AdminReceiver.class);
		if (mDPM.isAdminActive(who)) {
			ivStatus.setImageResource(R.drawable.admin_activated);
		} else {
			ivStatus.setImageResource(R.drawable.admin_inactivated);
		}

		rlActive.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (mDPM.isAdminActive(who)) {
					// 如果已激活,取消激活
					mDPM.removeActiveAdmin(who);
				} else {
					// 如果未激活,立即激活
					Intent intent = new Intent(
							DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
					intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, who);
					intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
							"打开超级管理员权限,可以一键锁屏,删除数据等");
					startActivityForResult(intent, REQUEST_CODE_ENABLE_ADMIN);
				}
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == REQUEST_CODE_ENABLE_ADMIN) {
			if (resultCode == Activity.RESULT_OK) {
				// 激活成功,更新ui
				ivStatus.setImageResource(R.drawable.admin_activated);
			}
		}

		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public void showNext() {
		// 判断是否已激活超级管理员
		if (!mDPM.isAdminActive(who)) {
			Toast.makeText(this, "要使用防盗功能,必须激活设备管理员!", Toast.LENGTH_SHORT)
					.show();
			return;
		}

		Intent intent = new Intent(this, Setup5Activity.class);
		startActivity(intent);
		finish();

		overridePendingTransition(R.anim.trans_in, R.anim.trans_out);// Activity切换的动画效果
	}

	@Override
	public void showPrevious() {
		Intent intent = new Intent(this, Setup3Activity.class);
		startActivity(intent);
		finish();

		overridePendingTransition(R.anim.trans_pre_in, R.anim.trans_pre_out);// Activity切换的动画效果
	}
}
