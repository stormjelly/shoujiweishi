package com.itheima.mobilesafeteach.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.service.AppLockService;
import com.itheima.mobilesafeteach.utils.ServiceStatusUtils;
import com.itheima.mobilesafeteach.utils.SmsUtils;
import com.itheima.mobilesafeteach.utils.SmsUtils.OnSmsListener;
import com.itheima.mobilesafeteach.view.SettingItemView;

/**
 * 高级工具
 * 
 * @author Kevin
 * 
 */
public class CommonToolsActivity extends Activity {

	private SettingItemView sivAppLock;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tools);

		//程序锁服务
		sivAppLock = (SettingItemView) findViewById(R.id.siv_applock);
		initAppLockService();
	}

	@Override
	protected void onStart() {
		super.onStart();

		boolean serviceRunning = ServiceStatusUtils.isServiceRunning(this,
				AppLockService.class);
		sivAppLock.setToggleOn(serviceRunning);
	}

	/**
	 * 归属地查询
	 * 
	 * @param view
	 */
	public void numberAddressQuery(View view) {
		startActivity(new Intent(this, NumberAddressActivity.class));
	}

	/**
	 * 常用号码查询
	 * 
	 * @param view
	 */
	public void commonNumberQuery(View view) {
		startActivity(new Intent(this, CommonNumberActivity.class));
	}

	/**
	 * 短信备份
	 */
	public void smsBackup(View view) {
		if (Environment.MEDIA_MOUNTED.equals(Environment
				.getExternalStorageState())) {
			final ProgressDialog dialog = new ProgressDialog(this);
			dialog.setMessage("正在备份短信...");
			dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);// 设置显示风格,此风格将展示一个进度条
			dialog.setCanceledOnTouchOutside(false);// 点击弹窗外侧不允许弹窗消失
			dialog.show();
			new Thread() {
				@Override
				public void run() {
					try {
						SmsUtils.smsBackup(CommonToolsActivity.this,
								new OnSmsListener() {

									@Override
									public void onSmsTotal(int total) {
										dialog.setMax(total);
									}

									@Override
									public void onSmsProgress(int progress) {
										dialog.setProgress(progress);
									}
								});

					} catch (Exception e) {
						e.printStackTrace();
					}

					dialog.dismiss();
				}
			}.start();

		} else {
			Toast.makeText(this, "没有检测到sdcard!", Toast.LENGTH_SHORT).show();
		}
	}

	/**
	 * 短信还原
	 * 
	 * @param view
	 */
	public void smsRestore(View view) {
		if (Environment.MEDIA_MOUNTED.equals(Environment
				.getExternalStorageState())) {
			final ProgressDialog dialog = new ProgressDialog(this);
			dialog.setMessage("正在还原短信...");
			dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);// 设置显示风格,此风格将展示一个进度条
			dialog.setCanceledOnTouchOutside(false);// 点击弹窗外侧不允许弹窗消失
			dialog.show();
			new Thread() {
				@Override
				public void run() {
					try {
						SmsUtils.smsRestore(getApplicationContext(),
								new OnSmsListener() {

									@Override
									public void onSmsTotal(int total) {
										dialog.setMax(total);
									}

									@Override
									public void onSmsProgress(int progress) {
										dialog.setProgress(progress);
									}
								});
					} catch (Exception e) {
						e.printStackTrace();
					}

					dialog.dismiss();
				}
			}.start();

		} else {
			Toast.makeText(this, "没有检测到sdcard!", Toast.LENGTH_SHORT).show();
		}
	}

	/**
	 * 程序锁
	 * 
	 * @param view
	 */
	public void appLock(View view) {
		startActivity(new Intent(this, AppLockActivity.class));
	}

	/**
	 * 初始化程序锁服务
	 */
	private void initAppLockService() {
		//		<intent-filter>
		//          <action android:name="android.intent.action.MAIN" />
		//          <action android:name="android.settings.ACCESSIBILITY_SETTINGS" />
		//          <category android:name="android.intent.category.DEFAULT" />
		//          <category android:name="android.intent.category.VOICE_LAUNCH" />
		//          <category android:name="com.android.settings.SHORTCUT" />
		//      </intent-filter>

		sivAppLock.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				//跳到辅助功能设置页面
				Intent intent = new Intent(
						"android.settings.ACCESSIBILITY_SETTINGS");
				intent.addCategory(Intent.CATEGORY_DEFAULT);
				startActivity(intent);
			}
		});
	}
}
