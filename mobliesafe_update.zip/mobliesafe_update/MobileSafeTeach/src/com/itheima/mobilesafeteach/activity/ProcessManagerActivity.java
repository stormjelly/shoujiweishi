package com.itheima.mobilesafeteach.activity;

import java.util.ArrayList;

import se.emilsjolander.stickylistheaders.StickyListHeadersAdapter;
import se.emilsjolander.stickylistheaders.StickyListHeadersListView;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.format.Formatter;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SlidingDrawer;
import android.widget.SlidingDrawer.OnDrawerCloseListener;
import android.widget.SlidingDrawer.OnDrawerOpenListener;
import android.widget.TextView;
import android.widget.Toast;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.domain.ProcessInfo;
import com.itheima.mobilesafeteach.engine.ProcessInfoProvider;
import com.itheima.mobilesafeteach.global.GlobalConstants;
import com.itheima.mobilesafeteach.service.AutoKillService;
import com.itheima.mobilesafeteach.utils.PrefUtils;
import com.itheima.mobilesafeteach.utils.ServiceStatusUtils;
import com.itheima.mobilesafeteach.view.ProgressDesView;
import com.itheima.mobilesafeteach.view.SettingItemView;

/**
 * 进程管理
 * 
 * @author Kevin
 * 
 */
public class ProcessManagerActivity extends Activity {

	private StickyListHeadersListView lvList;
	private LinearLayout llLoading;
	private ProgressDesView pbvProcessNum;
	private ProgressDesView pbvMemoryInfo;

	private SettingItemView sivShowSystem;
	private SettingItemView sivAutoKill;

	private ArrayList<ProcessInfo> mSystemProcessList;// 系统进程列表
	private ArrayList<ProcessInfo> mUserProcessList;// 用户进程列表

	private ProcessInfoAdapter mAdapter;

	private Handler mHandler = new Handler() {

		public void handleMessage(android.os.Message msg) {
			mAdapter = new ProcessInfoAdapter();
			lvList.setAdapter(mAdapter);
			llLoading.setVisibility(View.GONE);
		};
	};

	private int mRunningProcessNum;// 运行的进程数
	private int mTotalProcessNum;// 总的进程数

	private long mAvailMemory;// 可用内存
	private long mTotalMemory;// 总内存
	private long mUsedMemory;// 使用内存

	private ImageView ivArrow1;
	private ImageView ivArrow2;
	private SlidingDrawer mDrawer;
	private boolean isShowSystem;// 是否展示系统应用列表

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_process_manager);

		lvList = (StickyListHeadersListView) findViewById(R.id.lv_list);
		llLoading = (LinearLayout) findViewById(R.id.ll_loading);
		pbvProcessNum = (ProgressDesView) findViewById(R.id.pdv_process_num);
		pbvMemoryInfo = (ProgressDesView) findViewById(R.id.pdv_memory_info);

		initDrawer();

		mRunningProcessNum = ProcessInfoProvider.getRunningProcessNum(this);// 正在运行的进程数
		mTotalProcessNum = ProcessInfoProvider.getTotalProcessNum(this);// 获取总的进程数

		mAvailMemory = ProcessInfoProvider.getAvailMemory(this);// 可用内存
		mTotalMemory = ProcessInfoProvider.getTotalMemory(this);// 总内存

		// 更新进程和内存ui
		initProcessAndMemoryInfo();

		lvList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				ProcessInfo item = mAdapter.getItem(position);
				if (item != null) {
					CheckBox checkBox = (CheckBox) view
							.findViewById(R.id.cb_check);

					// 本应用不允许被勾选
					if (item.packageName.equals(getPackageName())) {
						return;
					}

					if (item.isChecked) {
						item.isChecked = false;
						checkBox.setChecked(false);
					} else {
						item.isChecked = true;
						checkBox.setChecked(true);
					}
				}
			}
		});

		initData();
	}

	// 初始化抽屉相关逻辑
	@SuppressWarnings("deprecation")
	private void initDrawer() {
		// 抽屉相关布局初始化
		mDrawer = (SlidingDrawer) findViewById(R.id.sd_drawer);
		sivShowSystem = (SettingItemView) findViewById(R.id.siv_show_system);
		sivAutoKill = (SettingItemView) findViewById(R.id.siv_auto_kill);

		ivArrow1 = (ImageView) findViewById(R.id.iv_arrow1);
		ivArrow2 = (ImageView) findViewById(R.id.iv_arrow2);

		// 启动箭头向上动画
		showArrowUp();

		// 监听抽屉打开
		mDrawer.setOnDrawerCloseListener(new OnDrawerCloseListener() {

			@Override
			public void onDrawerClosed() {
				showArrowUp();
			}
		});

		// 监听抽屉关闭
		mDrawer.setOnDrawerOpenListener(new OnDrawerOpenListener() {

			@Override
			public void onDrawerOpened() {
				showArrowDown();
			}
		});

		// 根据本地记录,更新选择框状态
		isShowSystem = PrefUtils.getBoolean(this,
				GlobalConstants.SHOW_SYSTEM_PROCESS, true);
		sivShowSystem.setToggleOn(isShowSystem);

		// 是否显示系统进程
		sivShowSystem.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				sivShowSystem.toggle();
				PrefUtils.putBoolean(getApplicationContext(),
						GlobalConstants.SHOW_SYSTEM_PROCESS,
						sivShowSystem.isToggleOn());

				isShowSystem = sivShowSystem.isToggleOn();

				mAdapter.notifyDataSetChanged();
			}
		});

		// 判断锁屏清理的广播是否正在运行
		boolean serviceRunning = ServiceStatusUtils.isServiceRunning(this,
				AutoKillService.class);
		sivAutoKill.setToggleOn(serviceRunning);

		// 锁屏清理
		sivAutoKill.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				sivAutoKill.toggle();

				Intent intent = new Intent(getApplicationContext(),
						AutoKillService.class);
				if (sivAutoKill.isToggleOn()) {
					// 启动锁屏清理的服务
					startService(intent);
				} else {
					// 关闭锁屏清理的服务
					stopService(intent);
				}
			}
		});
	}

	// 抽屉箭头向下
	private void showArrowDown() {
		//箭头向下时没有动画效果
		ivArrow1.clearAnimation();
		ivArrow2.clearAnimation();

		ivArrow1.setImageResource(R.drawable.drawer_arrow_down);
		ivArrow2.setImageResource(R.drawable.drawer_arrow_down);
	}

	// 抽屉箭头向上
	private void showArrowUp() {
		ivArrow1.setImageResource(R.drawable.drawer_arrow_up);
		ivArrow2.setImageResource(R.drawable.drawer_arrow_up);

		//第一个箭头动画
		AlphaAnimation alpha1 = new AlphaAnimation(0.2f, 1);
		alpha1.setDuration(600);
		alpha1.setRepeatCount(Animation.INFINITE);// 无限循环
		alpha1.setRepeatMode(Animation.REVERSE);// 动画执行结束后再逆向执行一次

		//第二个箭头动画,渐变顺序和第一个相反
		AlphaAnimation alpha2 = new AlphaAnimation(1, 0.2f);
		alpha2.setDuration(600);
		alpha2.setRepeatCount(Animation.INFINITE);// 无限循环
		alpha2.setRepeatMode(Animation.REVERSE);// 动画执行结束后再逆向执行一次

		ivArrow1.startAnimation(alpha1);
		ivArrow2.startAnimation(alpha2);
	}

	// 初始化进程和内存信息
	private void initProcessAndMemoryInfo() {
		mUsedMemory = mTotalMemory - mAvailMemory;// 已使用的内存

		// 更新进程相关信息
		pbvProcessNum.setTitle("进程数:");
		pbvProcessNum.setLeftText("正在运行" + mRunningProcessNum + "个");
		pbvProcessNum.setRightText("可有进程数:" + mTotalProcessNum);
		int processProgress = mRunningProcessNum * 100 / mTotalProcessNum;
		pbvProcessNum.setProgress(processProgress);

		// 更新内存相关信息
		pbvMemoryInfo.setTitle("内存:");
		pbvMemoryInfo.setLeftText("占用内存:"
				+ Formatter.formatFileSize(this, mUsedMemory));
		pbvMemoryInfo.setRightText("可用内存:"
				+ Formatter.formatFileSize(this, mAvailMemory));
		int memoryProgress = (int) (mUsedMemory * 100 / mTotalMemory);
		pbvMemoryInfo.setProgress(memoryProgress);
	}

	/**
	 * 初始化列表数据
	 */
	private void initData() {
		llLoading.setVisibility(View.VISIBLE);
		new Thread() {
			@Override
			public void run() {
				ArrayList<ProcessInfo> processInfoList = ProcessInfoProvider
						.getProcessInfos(ProcessManagerActivity.this);

				mSystemProcessList = new ArrayList<ProcessInfo>();
				mUserProcessList = new ArrayList<ProcessInfo>();
				for (ProcessInfo info : processInfoList) {
					if (info.isUserProcess) {
						mUserProcessList.add(info);
					} else {
						mSystemProcessList.add(info);
					}
				}

				mHandler.sendEmptyMessage(0);
			}
		}.start();
	}

	class ProcessInfoAdapter extends BaseAdapter implements
			StickyListHeadersAdapter {

		@Override
		public int getCount() {
			// 通过判断是否显示系统进程,更新list的数量
			if (isShowSystem) {
				return mUserProcessList.size() + mSystemProcessList.size();
			} else {
				return mUserProcessList.size();
			}
		}

		// 根据item位置获取对应的用户进程/系统进程对象
		@Override
		public ProcessInfo getItem(int position) {
			if (position > mUserProcessList.size() - 1) {
				return mSystemProcessList.get(position
						- mUserProcessList.size());
			} else {
				return mUserProcessList.get(position);
			}
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		// 初始化普通item布局
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
				convertView = View.inflate(ProcessManagerActivity.this,
						R.layout.list_process_info_item, null);
				holder = new ViewHolder();
				holder.ivIcon = (ImageView) convertView
						.findViewById(R.id.iv_icon);
				holder.tvName = (TextView) convertView
						.findViewById(R.id.tv_name);
				holder.tvMemory = (TextView) convertView
						.findViewById(R.id.tv_memory);
				holder.cbCheck = (CheckBox) convertView
						.findViewById(R.id.cb_check);

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			ProcessInfo item = getItem(position);
			holder.tvName.setText(item.name);
			holder.tvMemory.setText(Formatter.formatFileSize(
					ProcessManagerActivity.this, item.memory));
			holder.ivIcon.setImageDrawable(item.icon);

			// 本应用不允许被勾选
			if (item.packageName.equals(getPackageName())) {
				holder.cbCheck.setVisibility(View.GONE);
			} else {
				holder.cbCheck.setVisibility(View.VISIBLE);
				if (item.isChecked) {
					holder.cbCheck.setChecked(true);
				} else {
					holder.cbCheck.setChecked(false);
				}
			}

			return convertView;
		}

		// 初始化头布局
		@Override
		public View getHeaderView(int position, View convertView,
				ViewGroup parent) {
			if (convertView == null) {
				convertView = new TextView(ProcessManagerActivity.this);
				((TextView) convertView).setTextColor(Color.WHITE);
				((TextView) convertView).setBackgroundColor(Color.GRAY);
				((TextView) convertView).setPadding(5, 5, 5, 5);
			}
			
			System.out.println("getHeaderView:" + position);

			ProcessInfo item = getItem(position);

			if (item.isUserProcess) {
				((TextView) convertView).setText("用户进程("
						+ mUserProcessList.size() + ")");
			} else {
				((TextView) convertView).setText("系统进程("
						+ mSystemProcessList.size() + ")");
			}

			return convertView;
		}

		// 这个是用来标记浮动headerView的一个方法，返回相同ID的将被显示为同一组View
		@Override
		public long getHeaderId(int position) {
			ProcessInfo item = getItem(position);
			return item.isUserProcess ? 0 : 1;// 如果是用户进程,为第0组;如果是系统进程,为第1组
		}

	}

	static class ViewHolder {
		public ImageView ivIcon;
		public TextView tvName;
		public TextView tvMemory;
		public CheckBox cbCheck;
	}

	/**
	 * 全选
	 */
	public void selectAll(View view) {
		if (isShowSystem) {
			for (ProcessInfo info : mSystemProcessList) {
				info.isChecked = true;
			}
		}

		for (ProcessInfo info : mUserProcessList) {
			// 本应用不允许被勾选
			if (info.packageName.equals(getPackageName())) {
				continue;
			}

			info.isChecked = true;
		}

		mAdapter.notifyDataSetChanged();
	}

	/**
	 * 反选
	 * 
	 * @param view
	 */
	public void reverseSelect(View view) {
		if (isShowSystem) {
			for (ProcessInfo info : mSystemProcessList) {
				info.isChecked = !info.isChecked;
			}
		}

		for (ProcessInfo info : mUserProcessList) {
			// 本应用不允许被勾选
			if (info.packageName.equals(getPackageName())) {
				continue;
			}

			info.isChecked = !info.isChecked;
		}

		mAdapter.notifyDataSetChanged();
	}

	/**
	 * 一键清理
	 * 
	 * 需要权限:android.permission.KILL_BACKGROUND_PROCESSES
	 * 
	 * @param view
	 */
	public void killAll(View view) {
		ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);

		ArrayList<ProcessInfo> killedProcess = new ArrayList<ProcessInfo>();

		// 清除用户进程
		for (ProcessInfo info : mUserProcessList) {
			if (info.isChecked) {
				// android.os.Process.killProcess(android.os.Process.myPid());//app自杀
				am.killBackgroundProcesses(info.packageName);
				killedProcess.add(info);
			}
		}

		if (isShowSystem) {
			// 清除系统进程
			for (ProcessInfo info : mSystemProcessList) {
				if (info.isChecked) {
					am.killBackgroundProcesses(info.packageName);
					killedProcess.add(info);
				}
			}
		}

		long savedMemory = 0;

		// 从列表中删除已杀死的进程
		for (ProcessInfo info : killedProcess) {
			if (info.isUserProcess) {
				mUserProcessList.remove(info);
			} else {
				mSystemProcessList.remove(info);
			}

			savedMemory += info.memory;
		}

		Toast.makeText(
				this,
				String.format("共杀死了%d个进程,帮您释放了%s的空间!", killedProcess.size(),
						Formatter.formatFileSize(this, savedMemory)),
				Toast.LENGTH_SHORT).show();

		mAvailMemory = mAvailMemory + savedMemory;
		mRunningProcessNum = mRunningProcessNum - killedProcess.size();

		// 更新当前进程数和剩余内存
		initProcessAndMemoryInfo();

		mAdapter.notifyDataSetChanged();
	}
}
