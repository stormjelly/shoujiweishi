package com.itheima.mobilesafeteach.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.TrafficStats;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.format.Formatter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.itheima.mobilesafeteach.R;

/**
 * 流量统计
 * 
 * @author Kevin
 * 
 */
public class TrafficeMangerActivity extends Activity {

	private ListView lvList;
	private LinearLayout llLoading;

	private ArrayList<TrafficInfo> mList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_traffic_manager);
		lvList = (ListView) findViewById(R.id.lv_traffic);
		llLoading = (LinearLayout) findViewById(R.id.ll_loading);
		initData();

		//		long mobileRxBytes = TrafficStats.getMobileRxBytes();// 3g/2g下载总流量
		//		long mobileTxBytes = TrafficStats.getMobileTxBytes();// 3g/2g上传总流量
		//
		//		long totalRxBytes = TrafficStats.getTotalRxBytes();// wifi+手机下载流量
		//		long totalTxBytes = TrafficStats.getTotalTxBytes();// wifi+手机上传总流量
		//
		//		long uidRxBytes = TrafficStats.getUidRxBytes(10085);// 某个应用下载流量
		//		long uidTxBytes = TrafficStats.getUidTxBytes(10085);// 某个应用上传流量
		//		
		//		System.out.println(mobileRxBytes);
		//		System.out.println(mobileTxBytes);
		//		System.out.println(totalRxBytes);
		//		System.out.println(totalTxBytes);
		//		System.out.println(uidRxBytes);
		//		System.out.println(uidTxBytes);
	}

	private void initData() {
		new AsyncTask<Void, Void, Void>() {

			protected void onPreExecute() {
				llLoading.setVisibility(View.VISIBLE);
			};

			@Override
			protected Void doInBackground(Void... params) {
				mList = new ArrayList<TrafficInfo>();

				PackageManager pm = TrafficeMangerActivity.this
						.getPackageManager();
				List<PackageInfo> packages = pm.getInstalledPackages(0);// 获取已经安装的所有包

				for (PackageInfo packageInfo : packages) {
					TrafficInfo info = new TrafficInfo();

					String packageName = packageInfo.packageName;// 获取包名
					Drawable icon = packageInfo.applicationInfo.loadIcon(pm);// 获取图标

					String name = packageInfo.applicationInfo.loadLabel(pm)
							.toString();// 获取名称

					int uid = packageInfo.applicationInfo.uid;//获取应用的id

					info.packageName = packageName;
					info.icon = icon;
					info.name = name;
					info.uid = uid;
					info.rev = TrafficStats.getUidRxBytes(uid);// 某个应用下载流量
					info.send = TrafficStats.getUidTxBytes(uid);// 某个应用上传流量

					if (info.rev > 0 || info.send > 0) {//跳过流量为0的app
						mList.add(info);
					}
				}

				return null;
			}

			protected void onPostExecute(Void result) {
				llLoading.setVisibility(View.GONE);
				lvList.setAdapter(new TrafficAdapter());
			};

		}.execute();
	}

	class TrafficAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			return mList.size();
		}

		@Override
		public TrafficInfo getItem(int position) {
			return mList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
				convertView = View.inflate(getApplicationContext(),
						R.layout.list_traffic_item, null);
				holder = new ViewHolder();
				holder.tvName = (TextView) convertView
						.findViewById(R.id.tv_name);
				holder.tvRev = (TextView) convertView
						.findViewById(R.id.tv_traffic_rev);
				holder.tvSend = (TextView) convertView
						.findViewById(R.id.tv_traffic_send);
				holder.ivIcon = (ImageView) convertView
						.findViewById(R.id.iv_icon);

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			TrafficInfo item = getItem(position);

			holder.tvName.setText(item.name);
			holder.tvRev.setText("接收:"
					+ Formatter.formatFileSize(getApplicationContext(),
							item.rev));
			holder.tvSend.setText("发送:"
					+ Formatter.formatFileSize(getApplicationContext(),
							item.send));
			holder.ivIcon.setImageDrawable(item.icon);

			return convertView;
		}

	}

	static class ViewHolder {
		public TextView tvName;
		public TextView tvRev;
		public TextView tvSend;
		public ImageView ivIcon;
	}

	class TrafficInfo {
		public String packageName;
		public Drawable icon;
		public String name;
		public int uid;
		public long rev;//接收流量
		public long send;//发送流量
	}
}
