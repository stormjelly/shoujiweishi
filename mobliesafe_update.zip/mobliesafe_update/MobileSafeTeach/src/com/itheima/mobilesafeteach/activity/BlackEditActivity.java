package com.itheima.mobilesafeteach.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.db.dao.BlackNumberDao;

/**
 * 黑名单编辑页面(添加/修改)
 * 
 * @author Kevin
 * @date 2015-12-19
 */
public class BlackEditActivity extends Activity implements OnClickListener {

	public final static String ACTION_UPDATE = "com.itheima.mobilesafeteach.UPDATE";

	private EditText etBlackNumber;
	private RadioGroup rgMode;
	private TextView tvTitle;

	private Button btnOK;
	private Button btnCancel;

	private boolean isUpdate;// 表示是否是更新, true表示更新, false表示添加

	private int mUpdatePosition;// 记录更新条目的位置

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_black_edit);
		etBlackNumber = (EditText) findViewById(R.id.et_black_number);
		rgMode = (RadioGroup) findViewById(R.id.rg_mode);
		tvTitle = (TextView) findViewById(R.id.tv_title);

		btnOK = (Button) findViewById(R.id.btn_ok);
		btnCancel = (Button) findViewById(R.id.btn_cancel);
		btnOK.setOnClickListener(this);
		btnCancel.setOnClickListener(this);

		Intent intent = getIntent();
		String action = intent.getAction();
		if (ACTION_UPDATE.equals(action)) {
			// 更新黑名单
			isUpdate = true;
			
			btnOK.setText("更新");
			tvTitle.setText("更新黑名单");

			// 获取电话号码和拦截模式
			String number = intent.getStringExtra("number");
			int mode = intent.getIntExtra("mode", 1);
			mUpdatePosition = intent.getIntExtra("position", -1);

			// 禁用文本框(不允许修改电话号码)
			etBlackNumber.setEnabled(false);
			etBlackNumber.setText(number);

			// 更新RadioButton勾选位置
			switch (mode) {
			case 1:
				rgMode.check(R.id.rb_call);
				break;
			case 2:
				rgMode.check(R.id.rb_sms);
				break;
			case 3:
				rgMode.check(R.id.rb_all);
				break;

			default:
				break;
			}

		} else {
			// 添加黑名单
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_ok:
			String number = etBlackNumber.getText().toString().trim();
			if (!TextUtils.isEmpty(number)) {
				int checkedRadioButtonId = rgMode.getCheckedRadioButtonId();
				int mode = 1;
				// 根据当前选中的RadioButtonId来判断是哪种拦截模式
				switch (checkedRadioButtonId) {
				case R.id.rb_call:
					mode = 1;
					break;
				case R.id.rb_sms:
					mode = 2;
					break;
				case R.id.rb_all:
					mode = 3;
					break;

				default:
					break;
				}

				if (!isUpdate) {// 添加
					// 保存数据库
					boolean add = BlackNumberDao.getInstance(this).add(number,
							mode);
					if (add) {
						// 跳转到上一个页面, 回调上个页面的onActivityResult方法, 并传递相关数据
						Intent data = new Intent();
						data.putExtra("number", number);
						data.putExtra("mode", mode);
						setResult(Activity.RESULT_OK, data);
						finish();

						Toast.makeText(this, "添加成功!", Toast.LENGTH_SHORT)
								.show();
					} else {
						Toast.makeText(this, "添加失败!", Toast.LENGTH_SHORT)
								.show();
					}

				} else {// 更新
					boolean update = BlackNumberDao.getInstance(this).update(
							number, mode);
					if (update) {
						// 跳转到上一个页面, 回调上个页面的onActivityResult方法, 并传递相关数据
						Intent data = new Intent();
						data.putExtra("number", number);
						data.putExtra("mode", mode);
						data.putExtra("position", mUpdatePosition);
						setResult(Activity.RESULT_OK, data);
						finish();

						Toast.makeText(this, "更新成功!", Toast.LENGTH_SHORT)
								.show();
					} else {
						Toast.makeText(this, "更新失败!", Toast.LENGTH_SHORT)
								.show();
					}
				}

			} else {
				Toast.makeText(getApplicationContext(), "输入号码不能为空!",
						Toast.LENGTH_SHORT).show();
			}
			break;
		case R.id.btn_cancel:
			finish();
			break;

		default:
			break;
		}
	}
}
