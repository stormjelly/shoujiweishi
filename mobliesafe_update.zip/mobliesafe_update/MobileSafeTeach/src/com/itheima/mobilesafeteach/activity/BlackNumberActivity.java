package com.itheima.mobilesafeteach.activity;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.db.dao.BlackNumberDao;
import com.itheima.mobilesafeteach.db.dao.BlackNumberDao.BlackNumberInfo;

/**
 * 黑名单管理
 * 
 * @author Kevin
 * 
 */
public class BlackNumberActivity extends Activity {

	private static final int REQUEST_CODE_ADD = 1;
	private static final int REQUEST_CODE_UPDATE = 2;

	private ListView lvList;
	private ArrayList<BlackNumberInfo> mBlackNumberList = new ArrayList<BlackNumberDao.BlackNumberInfo>();
	private BlackNumberAdapter mAdapter;
	private LinearLayout llLoading;
	private ImageView ivEmpty;

	private boolean isLoading;// 表示是否正在加载

	private int mPosition;//记录当前被点击的item的位置

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_call_sms_safe);
		lvList = (ListView) findViewById(R.id.lv_list);
		llLoading = (LinearLayout) findViewById(R.id.ll_loading);
		ivEmpty = (ImageView) findViewById(R.id.iv_empty);

		// 监听listview的滑动事件
		lvList.setOnScrollListener(new OnScrollListener() {

			// 滑动状态发生变化
			// 1.静止->滚动 2.滚动->静止 3.惯性滑动
			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				if (scrollState == SCROLL_STATE_IDLE) {
					// 获取当前listview显示的最后一个item的位置
					int lastVisiblePosition = lvList.getLastVisiblePosition();

					// 判断是否应该加载下一页
					if (lastVisiblePosition >= mBlackNumberList.size() - 1
							&& !isLoading) {
						int totalCount = BlackNumberDao.getInstance(
								BlackNumberActivity.this).getTotalCount();

						// 判断是否已经到达最后一页
						if (mBlackNumberList.size() >= totalCount) {
							Toast.makeText(BlackNumberActivity.this, "没有更多数据了",
									Toast.LENGTH_SHORT).show();
							return;
						}

						Toast.makeText(BlackNumberActivity.this, "加载更多数据...",
								Toast.LENGTH_SHORT).show();
						System.out.println("加载更多数据...");
						startQuery();
					}
				}
			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {
			}
		});

		startQuery();

		// 点击item后进入黑名单编辑页面
		lvList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				mPosition = position;

				BlackNumberInfo info = mBlackNumberList.get(position);

				// 跳转到黑名单编辑页面
				Intent intent = new Intent();
				// 此处使用隐式意图, 是为了和添加黑名单逻辑区分开
				intent.setAction(BlackEditActivity.ACTION_UPDATE);
				intent.putExtra("number", info.number);
				intent.putExtra("mode", info.mode);
				startActivityForResult(intent, REQUEST_CODE_UPDATE);
			}
		});
	}

	/**
	 * 开始加载数据
	 */
	private void startQuery() {
		llLoading.setVisibility(View.VISIBLE);
		isLoading = true;
		new Thread() {
			@Override
			public void run() {
				try {
					Thread.sleep(600);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				//将下一页数据追加到当前集合中,而不是覆盖
				ArrayList<BlackNumberInfo> moreList = BlackNumberDao
						.getInstance(BlackNumberActivity.this).findPart(
								mBlackNumberList.size());//获取下一页数据

				//将下一页数据追加到当前集合中
				//0,1,...19 + 20,....39 = 0....39
				mBlackNumberList.addAll(moreList);

				// 运行在主线程
				runOnUiThread(new Runnable() {

					@Override
					public void run() {
						llLoading.setVisibility(View.GONE);// 隐藏进度条
						// 第一页数据
						if (mAdapter == null) {
							mAdapter = new BlackNumberAdapter();
							lvList.setAdapter(mAdapter);
							lvList.setEmptyView(ivEmpty);//设置数据为空时的布局
						} else {
							mAdapter.notifyDataSetChanged();// 刷新adapter
						}

						isLoading = false;
					}
				});
			}
		}.start();
	}

	/**
	 * 添加黑名单
	 * 
	 * @param view
	 */
	public void addBlackNumber(View v) {
		// 跳转到添加黑名单页面
		Intent intent = new Intent(this, BlackEditActivity.class);
		startActivityForResult(intent, REQUEST_CODE_ADD);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == REQUEST_CODE_ADD) {// 添加黑名单

			if (resultCode == Activity.RESULT_OK) {// 返回成功
				// 从添加黑名单页面获取相关参数
				String number = data.getStringExtra("number");
				int mode = data.getIntExtra("mode", 1);

				// 封装黑名单对象
				BlackNumberInfo info = new BlackNumberInfo();
				info.number = number;
				info.mode = mode;

				// 将新添加的对象添加到集合当中
				mBlackNumberList.add(info);

				// 刷新listview
				// 注意: 数据库获取数据应该逆序排列,保证最新添加的数据显示在最上方
				mAdapter.notifyDataSetChanged();
			}

		} else if (requestCode == REQUEST_CODE_UPDATE) {// 更新黑名单

			if (resultCode == Activity.RESULT_OK) {// 返回成功
				// 从添加黑名单页面获取相关参数
				// String number = data.getStringExtra("number");
				int mode = data.getIntExtra("mode", 1);

				// 获取待更新的对象
				BlackNumberInfo info = mBlackNumberList.get(mPosition);
				// 修改为最新的拦截模式
				info.mode = mode;

				// 刷新listview
				mAdapter.notifyDataSetChanged();
			}
		}

	}

	class BlackNumberAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			return mBlackNumberList.size();
		}

		@Override
		public Object getItem(int position) {
			return mBlackNumberList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view = null;
			ViewHolder holder = null;
			if (convertView == null) {
				view = View.inflate(BlackNumberActivity.this,
						R.layout.list_black_number_item, null);
				System.out.println("listview创建");

				// viewHolder类似一个容器,可以保存findViewById获得的view对象
				holder = new ViewHolder();
				holder.tvNumber = (TextView) view.findViewById(R.id.tv_number);
				holder.tvMode = (TextView) view.findViewById(R.id.tv_mode);
				holder.ivDelete = (ImageView) view.findViewById(R.id.iv_delete);
				// 将viewHolder设置给view对象,保存起来
				view.setTag(holder);
			} else {
				view = convertView;
				holder = (ViewHolder) view.getTag();// 从view对象中得到之前设置好的viewHolder
				System.out.println("listview重用了");
			}

			final BlackNumberInfo info = mBlackNumberList.get(position);
			holder.tvNumber.setText(info.number);

			holder.ivDelete.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// 从数据库中删除
					boolean delete = BlackNumberDao.getInstance(
							getApplicationContext()).delete(info.number);
					if (delete) {
						// 从内存列表中删除并刷新listview
						mBlackNumberList.remove(info);
						mAdapter.notifyDataSetChanged();
						Toast.makeText(getApplicationContext(), "删除成功",
								Toast.LENGTH_SHORT).show();

						if (mBlackNumberList.size() < 5) {
							//手动拉取下一页数据
							startQuery();
						}
					} else {
						Toast.makeText(getApplicationContext(), "删除失败",
								Toast.LENGTH_SHORT).show();
					}
				}
			});

			switch (info.mode) {
			case 1:
				holder.tvMode.setText("拦截电话");
				break;
			case 2:
				holder.tvMode.setText("拦截短信");
				break;
			case 3:
				holder.tvMode.setText("拦截电话+短信");
				break;
			}

			return view;
		}

	}

	static class ViewHolder {
		public TextView tvNumber;
		public TextView tvMode;
		public ImageView ivDelete;
	}
}
