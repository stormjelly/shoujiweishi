package com.itheima.mobilesafeteach.activity;

import java.io.File;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.format.Formatter;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.domain.AppInfo;
import com.itheima.mobilesafeteach.engine.AppInfoProvider;
import com.itheima.mobilesafeteach.view.ProgressDesView;

/**
 * 应用管理器
 * 
 * @author Kevin
 * 
 */
public class AppManagerActivity extends Activity implements OnClickListener {

	private static final int TYPE_TITLE = 0;// 标题类型
	private static final int TYPE_NORMAL = 1;// 普通类型

	private ProgressDesView pdvRom;// 内部存储
	private ProgressDesView pdvSdcard;// SD卡

	private TextView tvListHead;

	private ListView lvList;
	private LinearLayout llLoading;

	private ArrayList<AppInfo> mAppList;
	private ArrayList<AppInfo> mUserAppList;// 用户应用
	private ArrayList<AppInfo> mSystemAppList;// 系统应用

	private AppInfoAdapter mAdapter;

	private AppInfo mCurrentAppInfo;

	private Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			lvList.setAdapter(mAdapter);
			llLoading.setVisibility(View.GONE);
		};
	};
	private PopupWindow mPopupWindow;
	private View mPopupView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_app_manager);

		pdvRom = (ProgressDesView) findViewById(R.id.pdv_rom);
		pdvSdcard = (ProgressDesView) findViewById(R.id.pdv_sdcard);
		tvListHead = (TextView) findViewById(R.id.tv_head);

		lvList = (ListView) findViewById(R.id.lv_list);
		llLoading = (LinearLayout) findViewById(R.id.ll_loading);

		// 初始化使用空间和剩余空间数据
		initSpaceInfo();

		mAdapter = new AppInfoAdapter();
		loadAppInfos();

		// listview监听
		lvList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				mCurrentAppInfo = mAdapter.getItem(position);

				if (mCurrentAppInfo != null) {
					System.out.println(mCurrentAppInfo.name + "被点击!");
					showPopupWindow(view);
				}
			}
		});

		// 设置listview的滑动监听
		lvList.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {
				// System.out.println("onScroll:" + firstVisibleItem);
				if (mUserAppList != null && mSystemAppList != null) {
					if (firstVisibleItem <= mUserAppList.size()) {
						tvListHead.setText("用户应用(" + mUserAppList.size() + ")");
					} else {
						tvListHead.setText("系统应用(" + mSystemAppList.size()
								+ ")");
					}
				}
			}
		});

	}

	private void initSpaceInfo() {
		// 内部存储(Rom)
		File romFile = Environment.getDataDirectory();
		long romTotalSpace = romFile.getTotalSpace();// 总空间
		long romFreeSpace = romFile.getFreeSpace();// 剩余空间
		long romUsedSpace = romTotalSpace - romFreeSpace;// 使用空间

		// sdcard存储
		File sdcardFile = Environment.getExternalStorageDirectory();
		long sdcardTotalSpace = sdcardFile.getTotalSpace();// 总空间
		long sdcardFreeSpace = sdcardFile.getFreeSpace();// 剩余空间
		long sdcardUsedSpace = sdcardTotalSpace - sdcardFreeSpace;// 使用空间

		// 更新ui
		pdvRom.setTitle("内部存储:");
		pdvSdcard.setTitle("外部存储:");

		pdvRom.setLeftText(Formatter.formatFileSize(this, romUsedSpace) + "已用");
		pdvSdcard.setLeftText(Formatter.formatFileSize(this, sdcardUsedSpace)
				+ "已用");
		pdvRom.setRightText(Formatter.formatFileSize(this, romFreeSpace) + "可用");
		pdvSdcard.setRightText(Formatter.formatFileSize(this, sdcardFreeSpace)
				+ "可用");

		int romProgress = (int) (romUsedSpace * 100 / romTotalSpace);
		int sdcardProgress = (int) (sdcardUsedSpace * 100 / sdcardTotalSpace);
		pdvRom.setProgress(romProgress);
		pdvSdcard.setProgress(sdcardProgress);
	}

	/**
	 * 显示弹窗
	 */
	private void showPopupWindow(View view) {
		if (mPopupWindow == null) {
			mPopupView = View.inflate(this, R.layout.popup_appinfo, null);

			TextView tvUninstall = (TextView) mPopupView
					.findViewById(R.id.tv_uninstall);
			TextView tvLaunch = (TextView) mPopupView
					.findViewById(R.id.tv_launch);
			TextView tvShare = (TextView) mPopupView
					.findViewById(R.id.tv_share);
			TextView tvInfo = (TextView) mPopupView.findViewById(R.id.tv_info);

			// 设置监听事件
			tvUninstall.setOnClickListener(this);
			tvLaunch.setOnClickListener(this);
			tvShare.setOnClickListener(this);
			tvInfo.setOnClickListener(this);

			mPopupWindow = new PopupWindow(mPopupView,
					LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, true);
			mPopupWindow.setBackgroundDrawable(new ColorDrawable());// 必须设置背景,否则无法返回
			mPopupWindow.setAnimationStyle(R.style.PopAnimation);// 设置进入退出动画
		}

		mPopupWindow.showAsDropDown(view, 50, -view.getHeight());// 显示弹窗
	}

	/**
	 * 加载应用列表
	 */
	private void loadAppInfos() {
		llLoading.setVisibility(View.VISIBLE);
		new Thread() {
			public void run() {
				mAppList = AppInfoProvider.getAppInfos(AppManagerActivity.this);

				mUserAppList = new ArrayList<AppInfo>();
				mSystemAppList = new ArrayList<AppInfo>();
				for (AppInfo info : mAppList) {
					if (info.isUserApp) {
						mUserAppList.add(info);
					} else {
						mSystemAppList.add(info);
					}
				}

				mHandler.sendEmptyMessage(0);
			};
		}.start();
	}

	// 应用信息适配器
	class AppInfoAdapter extends BaseAdapter {

		/**
		 * 返回总数量,包括两个标题栏
		 */
		@Override
		public int getCount() {
			return 1 + mUserAppList.size() + 1 + mSystemAppList.size();
		}

		/**
		 * 返回当前的对象
		 */
		@Override
		public AppInfo getItem(int position) {
			if (position == 0 || position == 1 + mUserAppList.size()) {// 判断是否是标题栏
				return null;
			}

			AppInfo appInfo;
			if (position < mUserAppList.size() + 1) {// 判断是否是用户应用
				appInfo = mUserAppList.get(position - 1);
			} else {// 系统应用
				appInfo = mSystemAppList
						.get(position - mUserAppList.size() - 2);
			}
			return appInfo;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		/**
		 * 返回当前view的类型
		 */
		@Override
		public int getItemViewType(int position) {
			if (position == 0 || position == 1 + mUserAppList.size()) {
				return TYPE_TITLE;// 标题栏
			} else {
				return TYPE_NORMAL;// 应用信息
			}
		}

		/**
		 * 返回当前item的类型个数
		 */
		@Override
		public int getViewTypeCount() {
			return 2;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			int type = getItemViewType(position);// 获取item的类型
			switch (type) {
			case TYPE_TITLE:// 标题类型
				if (convertView == null) {// 初始化convertView
					convertView = new TextView(AppManagerActivity.this);
					((TextView) convertView).setTextColor(Color.WHITE);
					((TextView) convertView).setBackgroundColor(Color.GRAY);
					((TextView) convertView).setPadding(5, 5, 5, 5);
					System.out.println("初始化标题");
				}

				if (position == 0) {
					((TextView) convertView).setText("用户应用("
							+ mUserAppList.size() + ")");
				} else {
					((TextView) convertView).setText("系统应用("
							+ mSystemAppList.size() + ")");
				}
				break;
			case TYPE_NORMAL:// 普通类型
				ViewHolder holder;
				if (convertView == null) {
					convertView = View.inflate(AppManagerActivity.this,
							R.layout.list_appinfo_item, null);

					holder = new ViewHolder();
					holder.ivIcon = (ImageView) convertView
							.findViewById(R.id.iv_icon);
					holder.tvName = (TextView) convertView
							.findViewById(R.id.tv_name);
					holder.tvLocation = (TextView) convertView
							.findViewById(R.id.tv_location);
					holder.tvSize = (TextView) convertView
							.findViewById(R.id.tv_size);

					convertView.setTag(holder);
					System.out.println("初始化应用信息");
				} else {
					holder = (ViewHolder) convertView.getTag();
				}

				AppInfo appInfo = getItem(position);
				holder.ivIcon.setImageDrawable(appInfo.icon);
				holder.tvName.setText(appInfo.name);
				holder.tvSize.setText(Formatter.formatFileSize(
						getApplicationContext(), appInfo.size));

				if (appInfo.isRom) {
					holder.tvLocation.setText("手机内存");
				} else {
					holder.tvLocation.setText("外置存储卡");
				}

				break;

			default:
				break;
			}

			return convertView;
		}
	}

	static class ViewHolder {
		public ImageView ivIcon;
		public TextView tvName;
		public TextView tvLocation;
		public TextView tvSize;
	}

	@Override
	public void onClick(View v) {
		if (mCurrentAppInfo == null) {
			return;
		}
		switch (v.getId()) {
		case R.id.tv_uninstall:
			System.out.println("卸载" + mCurrentAppInfo.name);
			uninstall();
			break;
		case R.id.tv_launch:
			System.out.println("启动" + mCurrentAppInfo.name);
			launchApp();
			break;
		case R.id.tv_share:
			System.out.println("分享" + mCurrentAppInfo.name);
			shareApp();
			break;
		case R.id.tv_info:
			System.out.println("信息" + mCurrentAppInfo.name);
			showInfo();
			break;

		default:
			break;
		}

		if (mPopupWindow != null) {
			mPopupWindow.dismiss();
		}
	}

	/**
	 * 卸载
	 */
	private void uninstall() {
		if (mCurrentAppInfo.isUserApp) {
			Intent intent = new Intent();
			intent.setAction(Intent.ACTION_DELETE);
			intent.addCategory(Intent.CATEGORY_DEFAULT);
			intent.setData(Uri.parse("package:" + mCurrentAppInfo.packageName));
			startActivityForResult(intent, 0);
		} else {
			Toast.makeText(this, "无法卸载系统程序!", Toast.LENGTH_SHORT).show();
		}
	}

	/**
	 * 启动App
	 */
	private void launchApp() {
		try {
			PackageManager pm = this.getPackageManager();
			Intent intent = pm
					.getLaunchIntentForPackage(mCurrentAppInfo.packageName);// 获取应用入口的Intent
			startActivity(intent);// 启动应用
		} catch (Exception e) {
			e.printStackTrace();
			Toast.makeText(this, "无法启动该应用!", Toast.LENGTH_SHORT).show();
		}
	}

	/**
	 * 分享 此方法会呼起系统中所有支持文本分享的app列表
	 */
	private void shareApp() {
		Intent intent = new Intent(Intent.ACTION_SEND);
		intent.addCategory(Intent.CATEGORY_DEFAULT);
		intent.setType("text/plain");
		intent.putExtra(Intent.EXTRA_TEXT,
				"分享给你一个很好的应用哦! 下载地址: https://play.google.com/apps/details?id="
						+ mCurrentAppInfo.packageName);
		startActivity(intent);
	}

	/**
	 * 展示应用基本信息
	 */
	private void showInfo() {
		// <intent-filter>
		// <action android:name="android.settings.APPLICATION_DETAILS_SETTINGS"
		// />
		// <category android:name="android.intent.category.DEFAULT" />
		// <data android:scheme="package" />
		// </intent-filter>
		Intent intent = new Intent(
				"android.settings.APPLICATION_DETAILS_SETTINGS");
		intent.addCategory(Intent.CATEGORY_DEFAULT);
		intent.setData(Uri.parse("package:" + mCurrentAppInfo.packageName));
		startActivity(intent);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// 卸载成功后重新加载应用列表
		// 此处不必判断resultCode是否是RESULT_OK, 因为4.1+系统即使卸载成功也始终返回RESULT_CANCEL
		loadAppInfos();
		super.onActivityResult(requestCode, resultCode, data);
	}

}
