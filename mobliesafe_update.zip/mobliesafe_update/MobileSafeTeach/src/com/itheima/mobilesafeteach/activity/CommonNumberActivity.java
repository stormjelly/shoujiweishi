package com.itheima.mobilesafeteach.activity;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.TextView;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.db.dao.CommonNumberDao;
import com.itheima.mobilesafeteach.db.dao.CommonNumberDao.CommonNumberChild;
import com.itheima.mobilesafeteach.db.dao.CommonNumberDao.CommonNumberGroup;

/**
 * 常用号码查询
 * 
 * @author Kevin
 * 
 */
public class CommonNumberActivity extends Activity {

	private ExpandableListView elvList;
	private ArrayList<CommonNumberGroup> mNumberGroups;
	private NumberAdapter mAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_common_number);
		elvList = (ExpandableListView) findViewById(R.id.elv_list);

		initData();
		mAdapter = new NumberAdapter();
		elvList.setAdapter(mAdapter);

		elvList.setOnChildClickListener(new OnChildClickListener() {

			@Override
			public boolean onChildClick(ExpandableListView parent, View v,
					int groupPosition, int childPosition, long id) {
				CommonNumberChild child = mAdapter.getChild(groupPosition,
						childPosition);

				// 跳转拨打电话的界面
				// <uses-permission android:name="android.permission.CALL_PHONE"
				// /> // 允许拨打电话权限
				Intent intent = new Intent(Intent.ACTION_DIAL);
				intent.setData(Uri.parse("tel://" + child.number));
				startActivity(intent);

				return false;
			}
		});
	}

	/**
	 * 初始化号码数据
	 */
	private void initData() {
		mNumberGroups = CommonNumberDao.getCommonNumberGroups(this);
	}

	/**
	 * 扩展listview的适配器
	 * 
	 * @author Kevin
	 * 
	 */
	class NumberAdapter extends BaseExpandableListAdapter {

		/**
		 * 获取组的个数
		 */
		@Override
		public int getGroupCount() {
			return mNumberGroups.size();
		}

		@Override
		public int getChildrenCount(int groupPosition) {
			return mNumberGroups.get(groupPosition).childs.size();
		}

		@Override
		public CommonNumberGroup getGroup(int groupPosition) {
			return mNumberGroups.get(groupPosition);
		}

		@Override
		public CommonNumberChild getChild(int groupPosition, int childPosition) {
			return mNumberGroups.get(groupPosition).childs.get(childPosition);
		}

		@Override
		public long getGroupId(int groupPosition) {
			return groupPosition;
		}

		@Override
		public long getChildId(int groupPosition, int childPosition) {
			return childPosition;
		}

		@Override
		public boolean hasStableIds() {
			return false;
		}

		@Override
		public View getGroupView(int groupPosition, boolean isExpanded,
				View convertView, ViewGroup parent) {
			TextView tvGroup;
			if (convertView == null) {
				tvGroup = new TextView(getApplicationContext());
				tvGroup.setTextColor(Color.BLACK);
				tvGroup.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
				tvGroup.setBackgroundColor(Color.parseColor("#33000000"));// 背景色为灰色
				tvGroup.setPadding(10, 10, 10, 10);
				// tvGroup.setText("       第" + groupPosition + "组");
			} else {
				tvGroup = (TextView) convertView;
			}
			tvGroup.setText(getGroup(groupPosition).name);
			return tvGroup;
		}

		@Override
		public View getChildView(int groupPosition, int childPosition,
				boolean isLastChild, View convertView, ViewGroup parent) {
			TextView tvChild;
			if (convertView == null) {
				tvChild = new TextView(getApplicationContext());
				tvChild.setTextColor(Color.BLACK);
				tvChild.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
				tvChild.setPadding(8, 8, 8, 8);
				// tvGroup.setText("第" + groupPosition + "组" + ";第" +
				// childPosition
				// + "项");
			} else {
				tvChild = (TextView) convertView;
			}

			CommonNumberChild child = getChild(groupPosition, childPosition);
			tvChild.setText(child.name + "\n" + child.number);
			return tvChild;
		}

		/**
		 * 表示孩子是否可以点击选中
		 */
		@Override
		public boolean isChildSelectable(int groupPosition, int childPosition) {
			return true;
		}

	}
}
