package com.itheima.mobilesafeteach.service;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Service;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.telephony.SmsManager;

import com.itheima.mobilesafeteach.global.GlobalConstants;
import com.itheima.mobilesafeteach.utils.PrefUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;

public class LocationService extends Service {

	private LocationManager lm;
	private MyLocationListener listener;

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	public void onCreate() {
		lm = (LocationManager) getSystemService(LOCATION_SERVICE);// 获取系统位置服务

		Criteria criteria = new Criteria();
		criteria.setAccuracy(Criteria.ACCURACY_FINE);// 准确度良好
		criteria.setCostAllowed(true);// 是否允许花费(比如网络定位)
		String bestProvider = lm.getBestProvider(criteria, true);// 获取当前最好的位置提供者

		System.out.println("位置提供者:" + bestProvider);

		listener = new MyLocationListener();// 位置监听器
		lm.requestLocationUpdates(bestProvider, 0, 0, listener);// 更新位置,
																// 参2和参3设置为0,表示只要位置有变化就立即更新
	};

	class MyLocationListener implements LocationListener {

		// 位置发生变化
		@Override
		public void onLocationChanged(Location location) {
			System.out.println("onLocationChanged");
			String longitude = "j:" + location.getLongitude() + "\n";// 精度
			String latitude = "w:" + location.getLatitude() + "\n";// 纬度
			// String accuracy = "a:" + location.getAccuracy() + "\n";// 获取精确度

			System.out.println("j:" + longitude + ";w:" + latitude);

			// 在线经纬度查询
			loadLocation(location.getLongitude(), location.getLatitude());

			stopSelf();// 停止位置服务
		}

		// 位置提供者的状态发生变化
		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			System.out.println("onStatusChanged");
		}

		// 位置提供者可用
		@Override
		public void onProviderEnabled(String provider) {
			System.out.println("onProviderEnabled");
		}

		// 位置提供者不可用
		@Override
		public void onProviderDisabled(String provider) {
			System.out.println("onProviderDisabled");
		}

	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		lm.removeUpdates(listener);
		listener = null;
	}

	// 在线经纬度查询
	private void loadLocation(final double longitude, final double latitude) {
		// 接口地址：http://lbs.juhe.cn/api/getaddressbylngb
		// 支持格式：JSON/XML
		// 请求方式：GET
		// 请求示例：http://lbs.juhe.cn/api/getaddressbylngb?lngx=116.407431&lngy=39.914492
		// 请求参数：
		// 名称 类型 必填 说明
		// lngx String Y google地图经度 (如：119.9772857)
		// lngy String Y google地图纬度 (如：27.327578)
		// dtype String N 返回数据格式：json或xml,默认json

		HttpUtils utils = new HttpUtils();
		utils.configTimeout(3000);// 连接超时
		utils.configSoTimeout(3000);// 读取超时

		RequestParams params = new RequestParams();
		params.addQueryStringParameter("lngx", longitude + "");
		params.addQueryStringParameter("lngy", latitude + "");

		utils.send(HttpMethod.GET, "http://lbs.juhe.cn/api/getaddressbylngb",
				params, new RequestCallBack<String>() {

					@Override
					public void onFailure(HttpException e, String msg) {
						// 请求失败, 只能发送原始经纬度
						sendSms("j:" + longitude + ";w:" + latitude);
						e.printStackTrace();
					}

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// 请求成功
						String result = responseInfo.result;

						// 解析数据
						try {
							JSONObject jo = new JSONObject(result);

							if (jo.has("row")) {
								JSONObject jo1 = jo.getJSONObject("row");
								JSONObject jo2 = jo1.getJSONObject("result");

								String address = jo2
										.getString("formatted_address");
								sendSms("location:" + address);
								System.out.println("查询到的地址为:" + address);
							} else {
								// 没有查询到记录
								sendSms("j:" + longitude + ";w:" + latitude);
							}

						} catch (JSONException e) {
							e.printStackTrace();
						}
					}
				});

	}

	// 发送短信
	private void sendSms(String message) {
		// 向安全号码发送经纬度信息
		String safePhone = PrefUtils.getString(LocationService.this,
				GlobalConstants.PREF_SAFE_PHONE, "");
		SmsManager.getDefault().sendTextMessage(safePhone, null, message, null,
				null);
	}
}
