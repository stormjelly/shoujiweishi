package com.itheima.mobilesafeteach.service;

import java.lang.reflect.Method;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.telephony.PhoneStateListener;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;

import com.android.internal.telephony.ITelephony;
import com.itheima.mobilesafeteach.db.dao.BlackNumberDao;

public class BlackNumberService extends Service {

	private InnerSmsReceiver mReceiver;
	private TelephonyManager mTM;
	private MyPhoneListener mListener;
	private MyContentObserver mObserver;

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	public void onCreate() {
		// 动态注册短信广播
		mReceiver = new InnerSmsReceiver();
		IntentFilter filter = new IntentFilter();
		filter.addAction("android.provider.Telephony.SMS_RECEIVED");
		filter.setPriority(Integer.MAX_VALUE);
		registerReceiver(mReceiver, filter);

		mTM = (TelephonyManager) this.getSystemService(TELEPHONY_SERVICE);

		mListener = new MyPhoneListener();
		mTM.listen(mListener, PhoneStateListener.LISTEN_CALL_STATE);
	};

	/**
	 * 内容观察者
	 * 
	 * @author Kevin
	 * 
	 */
	class MyContentObserver extends ContentObserver {

		private String incomingNumber;

		public MyContentObserver(Handler handler, String incomingNumber) {
			super(handler);
			this.incomingNumber = incomingNumber;
		}

		/**
		 * 当数据库发生变化时,回调此方法
		 */
		@Override
		public void onChange(boolean selfChange) {
			System.out.println("call log changed...");

			// 删除日志
			deleteCallLog(incomingNumber);

			// 注销内容观察者
			getContentResolver().unregisterContentObserver(mObserver);
		}
	}

	class MyPhoneListener extends PhoneStateListener {
		@Override
		public void onCallStateChanged(int state, String incomingNumber) {
			switch (state) {
			case TelephonyManager.CALL_STATE_IDLE:
				break;
			case TelephonyManager.CALL_STATE_RINGING:
				int mode = BlackNumberDao.getInstance(BlackNumberService.this)
						.findMode(incomingNumber);
				if (mode == 1 || mode == 3) {
					System.out.println("挂断电话");

					// deleteCallLog(incomingNumber);
					mObserver = new MyContentObserver(new Handler(),
							incomingNumber);

					// 注册内容观察者
					getContentResolver().registerContentObserver(
							Uri.parse("content://call_log/calls"), true,
							mObserver);

					endCall();
				}
				break;

			default:
				break;
			}
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		unregisterReceiver(mReceiver);
		mTM.listen(mListener, PhoneStateListener.LISTEN_NONE);// 停止监听
		mListener = null;
		mReceiver = null;
	}

	/**
	 * 挂断电话 注意加权限: <uses-permission
	 * android:name="android.permission.CALL_PHONE"/>
	 */
	public void endCall() {
		// ITelephony.Stub.asInterface(ServiceManager.getService(Context.TELEPHONY_SERVICE));
		try {
			// 获取ServiceManager
			// Class clazz =
			// BlackNumberService.class.getClassLoader().loadClass(
			// "android.os.ServiceManager");
			Class clazz = Class.forName("android.os.ServiceManager");

			Method method = clazz.getMethod("getService", String.class);// 获取方法getService
			IBinder binder = (IBinder) method.invoke(null,
					Context.TELEPHONY_SERVICE);// 方法时静态的,不需要传递对象进去

			ITelephony telephony = ITelephony.Stub.asInterface(binder);// 获取ITelephony对象,前提是要先配置好aidl文件
			telephony.endCall();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 删除通话记录
	 */
	private void deleteCallLog(String number) {
		getContentResolver().delete(Uri.parse("content://call_log/calls"),
				"number=?", new String[] { number });
	}

	class InnerSmsReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			System.out.println("sms receive...");
			Object[] objs = (Object[]) intent.getExtras().get("pdus");
			for (Object object : objs) {
				SmsMessage msg = SmsMessage.createFromPdu((byte[]) object);
				String originatingAddress = msg.getOriginatingAddress();// 获取电话号码

				// 对短信内容进行关键词过滤
				String messageBody = msg.getMessageBody();
				if (messageBody != null && messageBody.contains("fapiao")) {
					abortBroadcast();
				}

				boolean exist = BlackNumberDao.getInstance(context).find(
						originatingAddress);
				if (exist) {
					int mode = BlackNumberDao.getInstance(context).findMode(
							originatingAddress);
					// 拦截短信 或者 拦截电话+短信, 2或3
					if (mode > 1) {
						abortBroadcast();
					}
				}
			}
		}
	}
}
