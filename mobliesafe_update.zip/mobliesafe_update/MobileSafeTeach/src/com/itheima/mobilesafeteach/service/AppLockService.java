package com.itheima.mobilesafeteach.service;

import java.util.ArrayList;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.view.accessibility.AccessibilityEvent;

import com.itheima.mobilesafeteach.activity.EnterPwdActivity;
import com.itheima.mobilesafeteach.db.dao.AppLockDao;
import com.itheima.mobilesafeteach.global.GlobalConstants;

/**
 * 使用系统辅助功能实现对系统页面的监听
 * 
 * @author Kevin
 * @date 2015-12-25
 */
public class AppLockService extends AccessibilityService {

	private AppLockDao mDao;
	private InnerReceiver mReceiver;

	private String mSkipPackageName;// 需要跳过验证的包名
	private ArrayList<String> mLockedPackages;
	private MyContentObserver mObserver;

	@Override
	public void onCreate() {
		super.onCreate();
		mDao = AppLockDao.getInstance(this);

		mLockedPackages = mDao.findAll();// 查询所有已加锁的应用列表

		//注册广播,监听需要跳过验证的包名
		mReceiver = new InnerReceiver();
		IntentFilter filter = new IntentFilter();
		filter.addAction(GlobalConstants.ACTION_SKIP_LOCK);
		registerReceiver(mReceiver, filter);

		// 监听程序锁数据库内容变化
		mObserver = new MyContentObserver(new Handler());
		getContentResolver().registerContentObserver(
				Uri.parse("content://com.itheima.mobilesafe/applockdb"), true,
				mObserver);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		unregisterReceiver(mReceiver);
		getContentResolver().unregisterContentObserver(mObserver);// 注销观察者
	}

	class InnerReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			if (GlobalConstants.ACTION_SKIP_LOCK.equals(action)) {
				// 看门狗得到了消息，临时的停止对某个应用程序的保护
				mSkipPackageName = intent.getStringExtra("packageName");
			}
		}
	}

	class MyContentObserver extends ContentObserver {

		public MyContentObserver(Handler handler) {
			super(handler);
		}

		@Override
		public void onChange(boolean selfChange) {
			System.out.println("数据变化了...");
			mLockedPackages = mDao.findAll();// 查询所有已加锁的应用列表
		}

	}

	@Override
	public void onAccessibilityEvent(AccessibilityEvent event) {
		//窗口状态发生变化
		if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
			String packageName = event.getPackageName().toString();//当前窗口页面所在的应用包名
			System.out.println("packageName:" + packageName);

			if (packageName.equals(mSkipPackageName)) {// 用过已经认证通过了,需跳过验证
				// System.out.println("无需验证...");
				return;
			}

			// if (mDao.find(packageName)) {// 查看当前页面是否在加锁的数据库中
			if (mLockedPackages.contains(packageName)) {
				Intent intent = new Intent(AppLockService.this,
						EnterPwdActivity.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				intent.putExtra("packageName", packageName);
				startActivity(intent);
			}
		}

	}

	@Override
	public void onInterrupt() {
		//辅助功能中断
	}

}
