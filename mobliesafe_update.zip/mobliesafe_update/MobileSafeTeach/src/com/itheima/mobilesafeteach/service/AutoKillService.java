package com.itheima.mobilesafeteach.service;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;

import com.itheima.mobilesafeteach.engine.ProcessInfoProvider;

/**
 * 锁屏清理进程的服务
 * 
 * @author Kevin
 * 
 */
public class AutoKillService extends Service {

	private InnerScreenOffReceiver mReceiver;
	private Timer mTimer;

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		mReceiver = new InnerScreenOffReceiver();

		// 监听屏幕关闭的广播, 注意,该广播只能在代码中注册,不能在清单文件中注册
		IntentFilter filter = new IntentFilter();
		filter.addAction(Intent.ACTION_SCREEN_OFF);
		registerReceiver(mReceiver, filter);

		// 启动定时器,定时清理任务
		mTimer = new Timer();
		mTimer.schedule(new TimerTask() {

			@Override
			public void run() {
				System.out.println("5秒运行一次!");
			}

		}, 0, 5000);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();

		unregisterReceiver(mReceiver);
		mReceiver = null;

		mTimer.cancel();
		mTimer = null;
	}

	/**
	 * 锁屏关闭的广播接收者
	 * 
	 * @author Kevin
	 * 
	 */
	class InnerScreenOffReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			System.out.println("屏幕关闭...");
			// 杀死后台所有运行的进程
			ProcessInfoProvider.killAll(context);
		}

	}
}
