package com.itheima.mobilesafeteach.service;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.activity.SplashActivity;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.RemoteViews;

public class ProtectService extends Service {

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();

		//初始化通知栏
		Notification notification = new Notification();
		//通知栏图标
		notification.icon = R.drawable.ic_launcher;
		//通知栏提示信息
		notification.tickerText = "黑马手机卫士启动了";
		//通知栏布局
		notification.contentView = new RemoteViews(getPackageName(),
				R.layout.view_notification);

		//点击通知栏后跳转activity
		Intent intent = new Intent(this, SplashActivity.class);
		PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
				intent, PendingIntent.FLAG_UPDATE_CURRENT);
		notification.contentIntent = pendingIntent;

		//在前台启动通知栏,不容易被系统杀死
		startForeground(100, notification);
	}

}
