package com.itheima.mobilesafeteach.service;

import java.util.Timer;
import java.util.TimerTask;

import android.app.PendingIntent;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.text.format.Formatter;
import android.widget.RemoteViews;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.activity.HomeActivity;
import com.itheima.mobilesafeteach.engine.ProcessInfoProvider;
import com.itheima.mobilesafeteach.receiver.MyWidget;

/**
 * 定时更新widget的service
 * 
 * @author Kevin
 * 
 */
public class UpdateWidgetService extends Service {

	private Timer mTimer;
	private AppWidgetManager mAWM;
	private InnerScreenReceiver mReceiver;

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		mAWM = AppWidgetManager.getInstance(this);

		startTimer();

		// 注册屏幕开启和关闭的广播接受者
		mReceiver = new InnerScreenReceiver();
		IntentFilter filter = new IntentFilter();
		filter.addAction(Intent.ACTION_SCREEN_OFF);
		filter.addAction(Intent.ACTION_SCREEN_ON);
		registerReceiver(mReceiver, filter);
	}

	private void startTimer() {
		// 启动定时器,每个5秒一更新
		mTimer = new Timer();
		mTimer.schedule(new TimerTask() {

			@Override
			public void run() {
				System.out.println("更新widget啦!");
				updateWidget();
			}
		}, 0, 5000);
	}

	/**
	 * 更新widget
	 */
	private void updateWidget() {
		// 初始化远程的view对象
		RemoteViews views = new RemoteViews(getPackageName(),
				R.layout.process_widget);

		views.setTextViewText(R.id.tv_running_tasks, "正在运行的软件:"
				+ ProcessInfoProvider.getRunningProcessNum(this));
		views.setTextViewText(
				R.id.tv_memory_left,
				"可用内存:"
						+ Formatter.formatFileSize(this,
								ProcessInfoProvider.getAvailMemory(this)));

		// 初始化延迟意图,pending是等待的意思
		Intent intent = new Intent(this, HomeActivity.class);
		PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
				intent, PendingIntent.FLAG_UPDATE_CURRENT);

		// 当点击widget布局时,跳转到主页面
		views.setOnClickPendingIntent(R.id.ll_root, pendingIntent);

		// 当一键清理被点击是,发送广播,清理内存
		Intent btnIntent = new Intent();
		btnIntent.setAction("com.itheima.mobilesafeteach.KILL_ALL");
		PendingIntent btnPendingIntent = PendingIntent.getBroadcast(this, 0,
				btnIntent, PendingIntent.FLAG_UPDATE_CURRENT);
		views.setOnClickPendingIntent(R.id.btn_clear, btnPendingIntent);

		// 初始化组件
		ComponentName provider = new ComponentName(this, MyWidget.class);

		// 更新widget
		mAWM.updateAppWidget(provider, views);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		mTimer.cancel();
		mTimer = null;

		// 注销广播接收者
		unregisterReceiver(mReceiver);
		mReceiver = null;
	}

	/**
	 * 屏幕关闭和开启的广播接收者
	 * 
	 * @author Kevin
	 * 
	 */
	class InnerScreenReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			if (Intent.ACTION_SCREEN_OFF.equals(action)) {// 屏幕关闭
				if (mTimer != null) {
					// 停止定时器
					mTimer.cancel();
					mTimer = null;
				}
			} else {// 屏幕开启
				startTimer();
			}
		}
	}

}
