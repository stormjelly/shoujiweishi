package com.itheima.mobilesafeteach.service;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

import com.itheima.mobilesafeteach.db.dao.AddressDao;
import com.itheima.mobilesafeteach.view.AddressToast;

/**
 * 监听来电的服务
 * 
 * @author Kevin
 * 
 */
public class AddressService extends Service {

	private TelephonyManager tm;
	private MyPhoneListener listener;
	private OutCallReceiver receiver;

	private AddressToast mToast;

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	public void onCreate() {
		listener = new MyPhoneListener();
		tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
		tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE);

		receiver = new OutCallReceiver();
		IntentFilter filter = new IntentFilter(Intent.ACTION_NEW_OUTGOING_CALL);
		registerReceiver(receiver, filter);

		mToast = new AddressToast(this);
	};

	@Override
	public void onDestroy() {
		super.onDestroy();
		tm.listen(listener, PhoneStateListener.LISTEN_NONE);
		listener = null;

		unregisterReceiver(receiver);
	}

	class MyPhoneListener extends PhoneStateListener {

		@Override
		public void onCallStateChanged(int state, String incomingNumber) {
			switch (state) {
			case TelephonyManager.CALL_STATE_RINGING:
				String address = AddressDao.getAddress(getApplicationContext(),
						incomingNumber);
				mToast.show(address);
				break;
			case TelephonyManager.CALL_STATE_IDLE:
				mToast.hide();
				break;
			default:
				break;
			}
			super.onCallStateChanged(state, incomingNumber);
		}
	}

	class OutCallReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			String number = getResultData();
			String address = AddressDao.getAddress(getApplicationContext(),
					number);
			mToast.show(address);
		}
	}
}
