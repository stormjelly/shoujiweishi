package com.itheima.mobilesafeteach.test;

import java.util.ArrayList;

import android.test.AndroidTestCase;

import com.itheima.mobilesafeteach.domain.AppInfo;
import com.itheima.mobilesafeteach.engine.AppInfoProvider;

public class TestAppInfo extends AndroidTestCase {

	public void testAppInfo() {
		ArrayList<AppInfo> appInfos = AppInfoProvider.getAppInfos(getContext());
		for (AppInfo appInfo : appInfos) {
			System.out.println(appInfo);
		}
	}
}
