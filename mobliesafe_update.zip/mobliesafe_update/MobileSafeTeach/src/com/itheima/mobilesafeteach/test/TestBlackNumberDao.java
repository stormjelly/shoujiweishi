package com.itheima.mobilesafeteach.test;

import java.util.Random;

import android.test.AndroidTestCase;

import com.itheima.mobilesafeteach.db.BlackNumberOpenHelper;
import com.itheima.mobilesafeteach.db.dao.BlackNumberDao;

public class TestBlackNumberDao extends AndroidTestCase {

	/**
	 * 测试数据创建
	 */
	public void testCreateDb() {
		BlackNumberOpenHelper helper = new BlackNumberOpenHelper(getContext());
		helper.getWritableDatabase();
	}

	/**
	 * 测试增加黑名单
	 */
	public void testAdd() {
		//添加100个号码,拦截模式随机
		Random random = new Random();
		for (int i = 0; i < 100; i++) {
			int mode = random.nextInt(3) + 1;
			if (i < 10) {
				BlackNumberDao.getInstance(getContext()).add("1381234560" + i,
						mode);
			} else {
				BlackNumberDao.getInstance(getContext()).add("138123456" + i,
						mode);
			}
		}
	}

	/**
	 * 测试删除黑名单
	 */
	public void testDelete() {
		BlackNumberDao.getInstance(getContext()).delete("13812345601");
	}

	/**
	 * 测试更新黑名单
	 */
	public void testUpdate() {
		BlackNumberDao.getInstance(getContext()).update("13812345600", 2);
	}

	/**
	 * 测试查找黑名单
	 */
	public void testFind() {
		boolean find = BlackNumberDao.getInstance(getContext()).find(
				"13812345600");
		assertEquals(true, find);
	}

	/**
	 * 测试查找黑名单拦截模式
	 */
	public void testFindMode() {
		int mode = BlackNumberDao.getInstance(getContext()).findMode(
				"13812345600");
		System.out.println("拦截模式:" + mode);
	}
}
