package com.itheima.mobilesafeteach.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 专门访问和设置SharePreference的工具类, 保存和配置一些设置信息
 * 
 * @author Kevin
 * 
 */
public class PrefUtils {

	private static final String SHARE_PREFS_NAME = "config";

	private static SharedPreferences sPref;

	private static SharedPreferences getPreferences(Context ctx) {
		if (sPref == null) {
			sPref = ctx.getSharedPreferences(SHARE_PREFS_NAME,
					Context.MODE_PRIVATE);
		}

		return sPref;
	}

	public static void putBoolean(Context ctx, String key, boolean value) {
		getPreferences(ctx).edit().putBoolean(key, value).commit();
	}

	public static boolean getBoolean(Context ctx, String key,
			boolean defaultValue) {
		return getPreferences(ctx).getBoolean(key, defaultValue);
	}

	public static void putString(Context ctx, String key, String value) {
		getPreferences(ctx).edit().putString(key, value).commit();
	}

	public static String getString(Context ctx, String key, String defaultValue) {
		return getPreferences(ctx).getString(key, defaultValue);
	}

	public static void putInt(Context ctx, String key, int value) {
		getPreferences(ctx).edit().putInt(key, value).commit();
	}

	public static int getInt(Context ctx, String key, int defaultValue) {
		return getPreferences(ctx).getInt(key, defaultValue);
	}

	public static void remove(Context ctx, String key) {
		getPreferences(ctx).edit().remove(key).commit();
	}

}
