package com.itheima.mobilesafeteach.utils;

import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.SystemClock;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * 短信备份/还原工具类
 * 
 * @author Kevin
 * 
 */
public class SmsUtils {

	public static final String SDCARD_ROOT = Environment
			.getExternalStorageDirectory().getAbsolutePath();

	/**
	 * 短信备份 注意权限: <uses-permission android:name="android.permission.READ_SMS"/>
	 * <uses-permission android:name="android.permission.WRITE_SMS"/>
	 */
	public static void smsBackup(Context ctx, OnSmsListener callback)
			throws Exception {

		//查询短信数据库
		Uri uri = Uri.parse("content://sms/");// 所有短信
		Cursor cursor = ctx.getContentResolver().query(uri,
				new String[] { "address", "date", "type", "body" }, null, null,
				null);

		//回调通知短信总个数
		callback.onSmsTotal(cursor.getCount());

		//查询短信, 生成短信集合
		ArrayList<SmsInfo> list = new ArrayList<SmsInfo>();
		int progress = 0;
		while (cursor.moveToNext()) {
			SmsInfo info = new SmsInfo();

			String address = cursor.getString(0);
			String date = cursor.getString(1);
			String type = cursor.getString(2);
			String body = cursor.getString(3);

			info.address = address;
			info.date = date;
			info.type = type;
			info.body = body;

			list.add(info);

			progress++;
			callback.onSmsProgress(progress);
		}

		cursor.close();

		//使用Gson将集合序列化成为json字符串
		Gson gson = new Gson();
		String json = gson.toJson(list);

		//将json写到本地文件中
		FileWriter writer = new FileWriter(SDCARD_ROOT + "/sms.json");
		writer.write(json);
		writer.flush();
		writer.close();
	}

	/**
	 * 短信还原
	 */
	public static void smsRestore(Context ctx, OnSmsListener callback) {
		Gson gson = new Gson();
		try {
			// 初始化类型对象, 方便gson在解析json时识别出具体对象类型及泛型
			Type type = new TypeToken<ArrayList<SmsInfo>>() {
			}.getType();
			ArrayList<SmsInfo> list = gson.fromJson(new FileReader(SDCARD_ROOT
					+ "/sms.json"), type);

			// 将待恢复的短信总数回调给前端页面
			callback.onSmsTotal(list.size());

			// 将短信插入系统短信数据库
			ContentResolver resolver = ctx.getContentResolver();
			Uri uri = Uri.parse("content://sms/");// 所有短信

			int progress = 0;
			//优化: 每次插入前判断有没有存在, 如果已经存在, 就不在插入
			for (SmsInfo smsInfo : list) {
				//查询该短信是否已经存在
				Cursor cursor = resolver.query(uri, new String[] { "address" },
						"address=? and date=? and body=? and type=?",
						new String[] { smsInfo.address, smsInfo.date,
								smsInfo.body, smsInfo.type }, null);

				//如果该短信不存在,才恢复到本地数据库中
				if (!cursor.moveToFirst()) {
					ContentValues values = new ContentValues();
					values.put("address", smsInfo.address);
					values.put("body", smsInfo.body);
					values.put("type", smsInfo.type);
					values.put("date", smsInfo.date);

					resolver.insert(uri, values);

					progress++;
					callback.onSmsProgress(progress);

					SystemClock.sleep(300);// 为了方便看效果,故意延时0.3秒钟
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 短信回调接口
	 * 
	 * @author Kevin
	 * 
	 */
	public interface OnSmsListener {
		/**
		 * 获取短信总数
		 * 
		 * @param total
		 */
		public void onSmsTotal(int total);

		/**
		 * 实时获取备份/恢复进度
		 * 
		 * @param progress
		 */
		public void onSmsProgress(int progress);
	}

	//短信对象封装
	public static class SmsInfo {
		public String date;
		public String address;
		public String type;
		public String body;
	}
}
