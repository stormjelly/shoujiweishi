package com.itheima.mobilesafeteach.utils;

import java.util.List;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.Service;
import android.content.Context;

public class ServiceStatusUtils {

	/**
	 * 判断服务是否正在运行
	 */
	public static boolean isServiceRunning(Context ctx,
			Class<? extends Service> clazz) {
		ActivityManager am = (ActivityManager) ctx
				.getSystemService(Context.ACTIVITY_SERVICE);
		List<RunningServiceInfo> runningServices = am.getRunningServices(100);//获取所有后台运行的服务

		for (RunningServiceInfo runningServiceInfo : runningServices) {
			String className = runningServiceInfo.service.getClassName();
			if (className.equals(clazz.getName())) {
				return true;
			}
		}

		return false;
	}
}
