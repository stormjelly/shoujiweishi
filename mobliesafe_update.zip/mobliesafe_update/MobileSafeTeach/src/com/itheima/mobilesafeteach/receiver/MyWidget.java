package com.itheima.mobilesafeteach.receiver;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.itheima.mobilesafeteach.service.UpdateWidgetService;

/**
 * 窗口小部件widget
 * 
 * @author Kevin
 * 
 */
public class MyWidget extends AppWidgetProvider {

	/**
	 * widget的每次变化都会调用onReceive
	 */
	@Override
	public void onReceive(Context context, Intent intent) {
		super.onReceive(context, intent);
		System.out.println("MyWidget: onReceive");
	}

	/**
	 * 当widget第一次被添加时,调用onEnable
	 */
	@Override
	public void onEnabled(Context context) {
		super.onEnabled(context);
		System.out.println("MyWidget: onEnabled");
		// 启动更新widget的服务
		context.startService(new Intent(context, UpdateWidgetService.class));
	}

	/**
	 * 当widget完全从桌面移除时,调用onDisabled
	 */
	@Override
	public void onDisabled(Context context) {
		super.onDisabled(context);
		System.out.println("MyWidget: onDisabled");
		// 停止更新widget的服务
		context.stopService(new Intent(context, UpdateWidgetService.class));
	}

	/**
	 * 新增widget时,或者widget更新时,调用onUpdate 更新时间取决于xml中配置的时间,最短为半小时
	 */
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,
			int[] appWidgetIds) {
		super.onUpdate(context, appWidgetManager, appWidgetIds);
		System.out.println("MyWidget: onUpdate");
		// 启动更新widget的服务
		context.startService(new Intent(context, UpdateWidgetService.class));
	}

	/**
	 * 删除widget时,调onDeleted
	 */
	@Override
	public void onDeleted(Context context, int[] appWidgetIds) {
		super.onDeleted(context, appWidgetIds);
		System.out.println("MyWidget: onDeleted");
	}

	/**
	 * 当widget大小发生变化时,调用此方法
	 */
	@Override
	public void onAppWidgetOptionsChanged(Context context,
			AppWidgetManager appWidgetManager, int appWidgetId,
			Bundle newOptions) {
		System.out.println("MyWidget: onAppWidgetOptionsChanged");
	}

}
