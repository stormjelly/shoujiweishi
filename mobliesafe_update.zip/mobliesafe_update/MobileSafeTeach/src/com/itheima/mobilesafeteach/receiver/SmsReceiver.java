package com.itheima.mobilesafeteach.receiver;

import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.telephony.SmsMessage;

import com.itheima.mobilesafeteach.R;
import com.itheima.mobilesafeteach.global.GlobalConstants;
import com.itheima.mobilesafeteach.service.LocationService;
import com.itheima.mobilesafeteach.utils.PrefUtils;

/**
 * 短信拦截
 * 
 * @author Kevin
 * 
 */
public class SmsReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		boolean protecting = PrefUtils.getBoolean(context,
				GlobalConstants.PREF_IS_PROTECTING, false);
		if (!protecting) {
			return;// 如果没有开启防盗保护,直接返回
		}

		Object[] pdus = (Object[]) intent.getExtras().get("pdus");
		for (Object obj : pdus) {
			SmsMessage msg = SmsMessage.createFromPdu((byte[]) obj);
			String address = msg.getOriginatingAddress();
			String body = msg.getMessageBody();
			System.out.println("收到短信了:" + body + ";发信人:" + address);

			if ("#*location*#".equals(body)) {
				System.out.println("获取手机地理位置");
				context.startService(new Intent(context, LocationService.class));// 开启位置服务
				abortBroadcast();// 中断广播的传递
			} else if ("#*alarm*#".equals(body)) {
				System.out.println("播放报警铃声");
				MediaPlayer player = MediaPlayer.create(context, R.raw.ylzs);
				player.setVolume(1.0f, 1.0f);
				player.setLooping(true);
				player.start();
				abortBroadcast();
			} else if ("#*wipedata*#".equals(body)) {
				System.out.println("清除手机数据");
				DevicePolicyManager dpm = (DevicePolicyManager) context
						.getSystemService(Context.DEVICE_POLICY_SERVICE);
				ComponentName who = new ComponentName(context,
						AdminReceiver.class);
				if (dpm.isAdminActive(who)) {
					dpm.wipeData(DevicePolicyManager.WIPE_EXTERNAL_STORAGE);// 清除sdcard内容
				}

				abortBroadcast();
			} else if ("#*lockscreen*#".equals(body)) {
				System.out.println("锁屏");
				DevicePolicyManager dpm = (DevicePolicyManager) context
						.getSystemService(Context.DEVICE_POLICY_SERVICE);
				ComponentName who = new ComponentName(context,
						AdminReceiver.class);
				if (dpm.isAdminActive(who)) {
					dpm.lockNow();
					dpm.resetPassword("123", 0);// 设置锁屏密码
				}

				abortBroadcast();
			}
		}
	}
}
