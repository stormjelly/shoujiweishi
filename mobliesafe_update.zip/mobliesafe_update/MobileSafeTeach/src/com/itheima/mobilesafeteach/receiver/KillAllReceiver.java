package com.itheima.mobilesafeteach.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.itheima.mobilesafeteach.engine.ProcessInfoProvider;

/**
 * 杀死后台进程的广播接受者
 * 清单文件中配置action="com.itheima.mobilesafeteach.KILL_ALL"
 * 
 * @author Kevin
 * 
 */
public class KillAllReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		System.out.println("kill all...");
		// 杀死后台所有运行的进程
		ProcessInfoProvider.killAll(context);
	}

}
