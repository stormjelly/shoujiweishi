package com.itheima.mobilesafeteach.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.itheima.mobilesafeteach.global.GlobalConstants;
import com.itheima.mobilesafeteach.utils.PrefUtils;

public class BootCompleteReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		System.out.println("开机启动啦...");

		boolean protecting = PrefUtils.getBoolean(context,
				GlobalConstants.PREF_IS_PROTECTING, false);
		if (!protecting) {
			return;// 如果没有开启防盗保护,直接返回
		}

		String bindSim = PrefUtils.getString(context, GlobalConstants.PREF_SIM,
				null);// 获取绑定sim卡

		if (!TextUtils.isEmpty(bindSim)) {
			TelephonyManager telePhonyManager = (TelephonyManager) context
					.getSystemService(Context.TELEPHONY_SERVICE);
			String realSim = telePhonyManager.getSimSerialNumber();// 获取当前sim卡

			if (bindSim.equals(realSim)) {// sim卡没有发生变化
				System.out.println("手机安全哦亲");
			} else {
				System.out.println("sim卡发生变化啦!!!!我要报警!!!");
				String phone = PrefUtils.getString(context,
						GlobalConstants.PREF_SAFE_PHONE, "");

				// 向安全号码发送短信
				SmsManager sms = SmsManager.getDefault();
				sms.sendTextMessage(phone, null, "sim card changed!!!", null,
						null);
			}
		}

	}

}
