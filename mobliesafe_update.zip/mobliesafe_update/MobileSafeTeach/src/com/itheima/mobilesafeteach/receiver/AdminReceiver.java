package com.itheima.mobilesafeteach.receiver;

import android.app.admin.DeviceAdminReceiver;

public class AdminReceiver extends DeviceAdminReceiver {

}
