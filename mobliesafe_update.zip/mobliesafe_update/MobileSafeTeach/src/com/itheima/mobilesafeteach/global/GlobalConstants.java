package com.itheima.mobilesafeteach.global;

/**
 * 全局的常量声明
 * @author Kevin
 * @date 2015-12-22
 */
public interface GlobalConstants {

	public static final String PREF_SHOW_UPDATE = "showUpdate";//标记是否需要自动更新
	public static final String PREF_PASSWORD = "password";//记录手机防盗页面密码
	public static final String PREF_IS_CONFIG= "isConfig";//标记是否进入过手机防盗设置向导
	public static final String PREF_IS_PROTECTING= "protecting";//标记是否开启防盗保护
	public static final String PREF_SAFE_PHONE= "safe_phone";//安全号码
	public static final String PREF_SIM= "sim";//sim卡序列号
	
	public static final String SHOW_SYSTEM_PROCESS = "show_system_process";
	public static final String ACTION_SKIP_LOCK = "com.itheima.mobilesafeteach.ACTION_SKIP_LOCK";
}
