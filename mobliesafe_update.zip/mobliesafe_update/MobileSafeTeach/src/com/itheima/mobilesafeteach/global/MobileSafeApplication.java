package com.itheima.mobilesafeteach.global;

import java.io.File;
import java.io.PrintWriter;
import java.lang.Thread.UncaughtExceptionHandler;

import android.app.Application;
import android.os.Environment;

/**
 * 自定义全局Application
 * 
 * @author Kevin
 * 
 */
public class MobileSafeApplication extends Application {

	@Override
	public void onCreate() {
		super.onCreate();

		// 设置未捕获异常处理器
		//Thread.setDefaultUncaughtExceptionHandler(new MyUncaughtExceptionHandler());
	}

	class MyUncaughtExceptionHandler implements UncaughtExceptionHandler {

		// 未捕获的异常都会走到此方法中
		// Throwable是Exception和Error的父类
		@Override
		public void uncaughtException(Thread thread, Throwable ex) {
			System.out.println("产生了一个未处理的异常, 但是被哥捕获了...");
			// 将异常日志输入到本地文件中, 找机会上传到服务器,供技术人员分析
			File file = new File(Environment.getExternalStorageDirectory(),
					"error.log");
			try {
				PrintWriter writer = new PrintWriter(file);
				ex.printStackTrace(writer);
				writer.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			ex.printStackTrace();

			// 结束当前进程
			android.os.Process.killProcess(android.os.Process.myPid());
		}
	}
}
