package com.itheima.mobilesafeteach.db.dao;

import java.io.File;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * 病毒数据库的封装
 * 
 * @author Kevin
 * 
 */
public class AntiVirusDao {

	/**
	 * 根据签名的md5判断是否是病毒
	 * 
	 * @param md5
	 */
	public static boolean isVirus(Context ctx, String md5) {
		File dbFile = new File(ctx.getFilesDir(), "antivirus.db");
		SQLiteDatabase db = SQLiteDatabase.openDatabase(
				dbFile.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);

		Cursor cursor = db.rawQuery(
				"select count(*) from datable where md5=? ",
				new String[] { md5 });

		int count = 0;
		if (cursor.moveToFirst()) {
			count = cursor.getInt(0);
		}

		cursor.close();
		db.close();
		return count > 0;
	}
}
