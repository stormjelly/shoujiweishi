package com.itheima.mobilesafeteach.db.dao;

import java.io.File;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * 号码查询数据库
 * 
 * @author Kevin
 * 
 */
public class AddressDao {

	public static String getAddress(Context ctx, String number) {
		String address = "未知号码";

		File dbFile = new File(ctx.getFilesDir(), "address.db");
		SQLiteDatabase db = SQLiteDatabase.openDatabase(
				dbFile.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
		// 判断手机号码的合法性
		// 13,4,5,6,7,8
		if (number.matches("^1[345678]\\d{9}$")) {// 符合手机号格式
			Cursor cursor = db
					.rawQuery(
							"select location from data2 where id=(select outkey from data1 where id=?)",
							new String[] { number.substring(0, 7) });
			if (cursor != null) {
				if (cursor.moveToNext()) {
					address = cursor.getString(0);
					System.out.println("address:" + address);
				}

				cursor.close();
			}
		} else if (number.matches("^\\d+$")) {//判断是否是数字
			switch (number.length()) {
			case 3:
				// 匪警电话 ,110,120等
				address = "报警电话";
				break;
			case 4:
				// 模拟器电话,5554,5556
				address = "模拟器";
				break;
			case 5:
				// 客服电话,95555
				address = "客服电话";
				break;
			case 7:
			case 8:
				// 本地电话
				address = "本地电话";
				break;
			default:
				if (number.startsWith("0") && number.length() > 10) {// 座机号码
					Cursor cursor = db.rawQuery(
							"select location from data2 where area=?",
							new String[] { number.substring(1, 4) });

					if (cursor.moveToNext()) {// 先查询前4位
						address = cursor.getString(0);
					} else {// 如果前4位没有数据,就查询前3位
						cursor.close();

						cursor = db.rawQuery(
								"select location from data2 where area=?",
								new String[] { number.substring(1, 3) });
						if (cursor.moveToNext()) {
							address = cursor.getString(0);
						}

						cursor.close();
					}
				}
				break;
			}
		}

		db.close();//关闭数据库

		return address;
	}
}
