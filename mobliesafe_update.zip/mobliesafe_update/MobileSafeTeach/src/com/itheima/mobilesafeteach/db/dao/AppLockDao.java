package com.itheima.mobilesafeteach.db.dao;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

import com.itheima.mobilesafeteach.db.AppLockOpenHelper;

/**
 * 程序锁数据库封装
 * 
 * @author Kevin
 * 
 */
public class AppLockDao {

	private static AppLockDao sInstance;
	private AppLockOpenHelper mHelper;

	private Context mContext;

	private AppLockDao(Context ctx) {
		mHelper = new AppLockOpenHelper(ctx);
		mContext = ctx;
	};

	/**
	 * 获取单例对象
	 * 
	 * @param ctx
	 * @return
	 */
	public static AppLockDao getInstance(Context ctx) {
		if (sInstance == null) {
			synchronized (AppLockDao.class) {
				if (sInstance == null) {
					sInstance = new AppLockDao(ctx);
				}
			}
		}

		return sInstance;
	}

	/**
	 * 增加程序锁应用
	 */
	public boolean add(String packageName) {
		SQLiteDatabase db = mHelper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("packagename", packageName);
		long insert = db.insert("applock", null, values);
		db.close();

		// 数据库改变后发送通知
		mContext.getContentResolver().notifyChange(
				Uri.parse("content://com.itheima.mobilesafe/applockdb"), null);

		return insert != -1;
	}

	/**
	 * 删除程序锁应用
	 * 
	 * @param number
	 */
	public boolean delete(String packageName) {
		SQLiteDatabase db = mHelper.getWritableDatabase();
		int delete = db.delete("applock", "packagename=?",
				new String[] { packageName });
		db.close();

		// 数据库改变后发送通知
		mContext.getContentResolver().notifyChange(
				Uri.parse("content://com.itheima.mobilesafe/applockdb"), null);
		return delete != 0;
	}

	/**
	 * 查找程序锁应用
	 * 
	 * @param number
	 * @return
	 */
	public boolean find(String packageName) {
		SQLiteDatabase db = mHelper.getWritableDatabase();
		Cursor cursor = db.query("applock", null, "packagename=?",
				new String[] { packageName }, null, null, null);

		boolean result = false;
		if (cursor.moveToFirst()) {
			result = true;
		}

		cursor.close();
		db.close();
		return result;
	}

	/**
	 * 查找已加锁列表
	 * 
	 * @return
	 */
	public ArrayList<String> findAll() {
		SQLiteDatabase db = mHelper.getWritableDatabase();
		Cursor cursor = db.query("applock", new String[] { "packagename" },
				null, null, null, null, null);

		ArrayList<String> list = new ArrayList<String>();
		while (cursor.moveToNext()) {
			String packageName = cursor.getString(0);
			list.add(packageName);
		}

		cursor.close();
		db.close();
		return list;
	}
}
