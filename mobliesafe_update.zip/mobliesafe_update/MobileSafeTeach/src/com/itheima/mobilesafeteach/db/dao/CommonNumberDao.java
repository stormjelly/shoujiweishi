package com.itheima.mobilesafeteach.db.dao;

import java.io.File;
import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class CommonNumberDao {

	/**
	 * 获取所有常用号码分组
	 * 
	 * @return
	 */
	public static ArrayList<CommonNumberGroup> getCommonNumberGroups(Context ctx) {
		File dbFile = new File(ctx.getFilesDir(), "commonnum.db");

		SQLiteDatabase db = SQLiteDatabase.openDatabase(
				dbFile.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
		Cursor cursor = db.query("classlist", new String[] { "name", "idx" },
				null, null, null, null, null);

		ArrayList<CommonNumberGroup> list = new ArrayList<CommonNumberDao.CommonNumberGroup>();
		while (cursor.moveToNext()) {
			CommonNumberGroup group = new CommonNumberGroup();
			String name = cursor.getString(0);
			String idx = cursor.getString(1);

			group.name = name;
			group.idx = idx;
			group.childs = getCommonNumberChilds(db, idx);

			list.add(group);
		}

		cursor.close();
		db.close();

		return list;
	}

	/**
	 * 获取某个分组下的所有电话
	 * 
	 * @param id
	 *            分组的id
	 */
	public static ArrayList<CommonNumberChild> getCommonNumberChilds(
			SQLiteDatabase db, String id) {
		Cursor cursor = db
				.query("table" + id, new String[] { "number", "name" }, null,
						null, null, null, null);

		ArrayList<CommonNumberChild> list = new ArrayList<CommonNumberDao.CommonNumberChild>();
		while (cursor.moveToNext()) {
			CommonNumberChild child = new CommonNumberChild();
			String number = cursor.getString(0);
			String name = cursor.getString(1);

			child.name = name;
			child.number = number;

			list.add(child);
		}

		cursor.close();
		return list;
	}

	/**
	 * 常用号码分组
	 * 
	 * @author Kevin
	 * 
	 */
	public static class CommonNumberGroup {
		public String name;
		public String idx;
		public ArrayList<CommonNumberChild> childs;
	}

	/**
	 * 常用号码
	 * 
	 * @author Kevin
	 * 
	 */
	public static class CommonNumberChild {
		public String name;
		public String number;
	}
}
