package com.itheima.mobilesafeteach.db.dao;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.itheima.mobilesafeteach.db.BlackNumberOpenHelper;

/**
 * 黑名单数据库封装
 * 
 * @author Kevin
 * 
 */
public class BlackNumberDao {

	private static BlackNumberDao sInstance;
	private BlackNumberOpenHelper mHelper;

	private BlackNumberDao(Context ctx) {
		mHelper = new BlackNumberOpenHelper(ctx);
	};

	/**
	 * 获取单例对象
	 * 
	 * @param ctx
	 * @return
	 */
	public static BlackNumberDao getInstance(Context ctx) {
		if (sInstance == null) {
			synchronized (BlackNumberDao.class) {
				if (sInstance == null) {
					sInstance = new BlackNumberDao(ctx);
				}
			}
		}

		return sInstance;
	}

	/**
	 * 增加黑名单
	 * 
	 * @param number
	 * @param mode
	 */
	public boolean add(String number, int mode) {
		SQLiteDatabase db = mHelper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("number", number);
		values.put("mode", mode);
		long insert = db.insert("blacknumber", null, values);
		db.close();

		return insert != -1;
	}

	/**
	 * 删除黑名单
	 * 
	 * @param number
	 */
	public boolean delete(String number) {
		SQLiteDatabase db = mHelper.getWritableDatabase();
		int delete = db.delete("blacknumber", "number=?",
				new String[] { number });
		db.close();
		return delete != 0;
	}

	/**
	 * 更新黑名单
	 * 
	 * @param number
	 * @param mode
	 */
	public boolean update(String number, int mode) {
		SQLiteDatabase db = mHelper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("mode", mode);
		int update = db.update("blacknumber", values, "number=?",
				new String[] { number });
		db.close();
		return update != 0;
	}

	/**
	 * 查找黑名单
	 * 
	 * @param number
	 * @return
	 */
	public boolean find(String number) {
		SQLiteDatabase db = mHelper.getWritableDatabase();
		Cursor cursor = db.query("blacknumber",
				new String[] { "number", "mode" }, "number=?",
				new String[] { number }, null, null, null);

		boolean result = false;
		if (cursor.moveToFirst()) {
			result = true;
		}

		cursor.close();
		db.close();
		return result;
	}

	/**
	 * 查找号码拦截模式
	 * 
	 * @param number
	 * @return
	 */
	public int findMode(String number) {
		SQLiteDatabase db = mHelper.getWritableDatabase();
		Cursor cursor = db.query("blacknumber", new String[] { "mode" },
				"number=?", new String[] { number }, null, null, null);

		int mode = -1;
		if (cursor.moveToFirst()) {
			mode = cursor.getInt(0);
		}

		cursor.close();
		db.close();
		return mode;
	}

	/**
	 * 查找黑名单列表
	 * 
	 * @return
	 */
	public ArrayList<BlackNumberInfo> findAll() {
		SQLiteDatabase db = mHelper.getWritableDatabase();
		Cursor cursor = db
				.query("blacknumber", new String[] { "number", "mode" }, null,
						null, null, null, null);

		ArrayList<BlackNumberInfo> list = new ArrayList<BlackNumberDao.BlackNumberInfo>();
		while (cursor.moveToNext()) {
			String number = cursor.getString(0);
			int mode = cursor.getInt(1);
			BlackNumberInfo info = new BlackNumberInfo();
			info.number = number;
			info.mode = mode;
			list.add(info);
		}

		cursor.close();
		db.close();
		return list;
	}

	/**
	 * 分页查找黑名单列表
	 * 
	 * @return
	 */
	public ArrayList<BlackNumberInfo> findPart(int startIndex) {
		SQLiteDatabase db = mHelper.getWritableDatabase();

		Cursor cursor = db
				.rawQuery(
						"select number,mode from blacknumber order by _id desc limit 20 offset ?",
						new String[] { String.valueOf(startIndex) });

		ArrayList<BlackNumberInfo> list = new ArrayList<BlackNumberDao.BlackNumberInfo>();
		while (cursor.moveToNext()) {
			String number = cursor.getString(0);
			int mode = cursor.getInt(1);
			BlackNumberInfo info = new BlackNumberInfo();
			info.number = number;
			info.mode = mode;
			list.add(info);
		}

		cursor.close();
		db.close();
		return list;
	}

	/**
	 * 获取黑名单数量
	 * 
	 * @return
	 */
	public int getTotalCount() {
		SQLiteDatabase db = mHelper.getWritableDatabase();
		Cursor cursor = db.rawQuery("select count(*) from blacknumber", null);

		int count = 0;
		if (cursor.moveToNext()) {
			count = cursor.getInt(0);
		}
		cursor.close();
		db.close();
		return count;
	}

	/**
	 * 黑名单对象
	 * 
	 * @author Kevin
	 * 
	 */
	public static class BlackNumberInfo {
		public String number;
		public int mode;

		@Override
		public String toString() {
			return "BlackNumberInfo [number=" + number + ", mode=" + mode + "]";
		}
	}

}
